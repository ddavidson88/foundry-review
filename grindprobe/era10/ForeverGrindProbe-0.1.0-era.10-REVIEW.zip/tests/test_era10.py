import unittest
import test_weapon
class Lifecycle(unittest.TestCase):
 def test_repull_after_close(self):
  l,g=test_weapon.WeaponTests().make()
  l.execute('startcombat(1); swing(1,player,mob,10); endcombat(2); old=G.json(G.session.records[1]); startcombat(3); swing(3,player,mob,20)')
  self.assertEqual(len(g.session.records),2)
  self.assertEqual(g.session.records[2].dmg_out,20)
  self.assertEqual(g.json(g.session.records[1]),l.globals().old)
  l.execute('endcombat(4); kill(4.1); finish(9)')
  s=g.db.sessions[1];self.assertIsNone(s.records[1].xp_total);self.assertEqual(s.records[2].xp_total,55)
  self.assertEqual(s.awards[1].record_id,s.records[2].record_id)
 def test_logout_export_once(self):
  for capture_first in (False,True):
   l,g=test_weapon.WeaponTests().make()
   l.execute('saves=0; local save=G.saveExport; G.saveExport=function() saves=saves+1; save() end')
   if capture_first:l.execute("event('PLAYER_LOGOUT')")
   l.execute('G.logoutFrame.scripts.OnEvent()')
   self.assertEqual(l.globals().saves,1)
 def test_death_gap_labeled(self):
  l,g=test_weapon.WeaponTests().make();l.execute("startcombat(1); health=0; event('PLAYER_DEAD'); health=100; startcombat(20)")
  self.assertTrue(g.session.episodes[1].time_to_next_pull_after_death)
