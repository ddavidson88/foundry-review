import unittest
import test_weapon
class Refine(unittest.TestCase):
 def make(self):return test_weapon.WeaponTests().make()
 def test_closed_guid_diagnostic(self):
  l,g=self.make();l.execute('hit(1); step(32); hit(33)')
  self.assertEqual(g.session.diagnostics.counts.closed_guid_reengagement,1)
  self.assertEqual(len(g.session.records),2)
 def test_multi_death_once(self):
  l,g=self.make();l.execute("startcombat(1); swing(1,mob,player,10); swing(2,mob2,player,10); health=0; event('PLAYER_DEAD'); cleu(3,'UNIT_DIED',nil,player); finish(4)")
  q=g.db.sessions[1].summary;self.assertEqual(q.player_deaths,1);self.assertEqual(q.flagged_records.player_died,2)
 def test_xp_scopes(self):
  l,g=self.make();l.execute("G.message('Boar dies, you gain 60 experience. (+5 exp Rested bonus)'); now=2; G.message('Boar dies, you gain 55 experience.'); G.message('You gain 100 experience.'); update(2,315); step(2.3); finish(6)")
  q=g.db.sessions[1].summary
  self.assertEqual((q.xp_actual,q.all_award_base,q.all_award_rested,q.unmatched_award_xp),(115,110,5,115))
  self.assertEqual(q.observed_character_xp,215)
 def test_fresh_state(self):
  l,g=self.make();l.execute('hit(1); healthmax=130; died(3)')
  r=g.session.records[1];self.assertEqual(r.state_engage.maxHP,100);self.assertEqual(r.state_end.maxHP,130)
 def test_identity(self):
  l,g=self.make();l.execute("a={[16]={link='|Hitem:25:1:0:0:0:0:0:0:6|h[A]|h'}}; b={[16]={link='|Hitem:25:1:0:0:0:0:0:0:7|h[A]|h'}}")
  self.assertEqual(g.weaponIdentity(l.globals().a),g.weaponIdentity(l.globals().b))
  l.execute("b[16].link='|Hitem:25:2:0:0:0:0:0:0:7|h[A]|h'")
  self.assertNotEqual(g.weaponIdentity(l.globals().a),g.weaponIdentity(l.globals().b))
 def test_recovery_measures(self):
  l,g=self.make();l.execute('startcombat(1); swing(1,mob,player,30); health=70; endcombat(3); health=80; startcombat(7)')
  e=g.session.episodes[1];r=g.session.recoveries[1]
  self.assertEqual((e.combat_duration,e.time_to_next_pull,r.hp_net_gain),(2,4,10))
  self.assertEqual(r.category,'post_damage');self.assertIsNone(r.time_to_full)
