local _,G=...
if not G.enabled then return end

-- One initial DB walk. Pending mutable objects reserve bounded space; closed
-- objects replace their reservation with one conservative depth-aware estimate.
function G.reserve(object,bytes)
    if G.bytes+bytes>=G.maxBytes-65536 then G.capacityClosing=true; return false end
    G.budget[object]=bytes; G.bytes=G.bytes+bytes; return true
end
function G.seal(object)
    local reserved=G.budget[object]; if not reserved then return end
    G.bytes=G.bytes-reserved+G.storageSize(object,5)+128
    G.budget[object]=nil
    if G.bytes>=G.maxBytes-65536 then G.capacityClosing=true end
end
function G.append(list,object,reservation)
    if not G.reserve(object,reservation) then return false end
    list[#list+1]=object; return true
end
local function hp() return UnitHealth("player") end
local function rage() return UnitPower("player",1) end
local weapons={Axes=true,["Two-Handed Axes"]=true,Maces=true,["Two-Handed Maces"]=true,
    Swords=true,["Two-Handed Swords"]=true,Daggers=true,Staves=true,Polearms=true,
    ["Fist Weapons"]=true,Unarmed=true,Bows=true,Crossbows=true,Guns=true,
    Thrown=true,Wands=true,Defense=true}
function G.skills()
    local out={}
    for i=1,GetNumSkillLines() do
        local name,header,_,rank,_,_,maximum=GetSkillLineInfo(i)
        if not header and weapons[name] then out[name]={rank=rank,max=maximum} end
    end
    return out
end
function G.context(reason,level)
    if not G.session or G.closing then return end
    if reason=="skill" then return end
    local sk=G.skills(); local signature=G.json(sk)
    if reason=="skill" and signature==G.skillSignature then return end
    local _,armor=UnitArmor("player"); local base,pos,neg=UnitAttackPower("player")
    local mh,oh=UnitAttackSpeed("player")
    local c={id=#G.session.contexts+1,t=G.now(),reason=reason,level=level or UnitLevel("player"),
        maxHP=UnitHealthMax("player"),effectiveUnitArmor=armor,
        attackPower=base and base+(pos or 0)+(neg or 0),crit=GetCritChance(),dodge=GetDodgeChance(),
        parry=GetParryChance(),block=GetBlockChance(),mhSpeed=mh,ohSpeed=oh,items={},skills=sk}
    for slot=16,18 do
        local link=GetInventoryItemLink("player",slot)
        c.items[slot]=link and {link=link} or {missing=true}
    end
    if not G.reserve({},2048) then return end -- per-context stop summary
    if not G.append(G.session.contexts,c,G.storageSize(c,5)+128) then return end
    G.seal(c); G.currentContext=c.id; G.skillSignature=signature
    if G.recovery then G.recovery.context_changed=true end
    for _,r in pairs(G.live) do
        if not r.t_end then
            r.flags.context_changed_midfight=true
            if reason=="equipment" then r.flags.gear_changed_midfight=true end
        end
    end
end
function G.weaponStart()
    local s=G.session
    s.record_schema=3; s.contexts={}; s.episodes={}; s.recoveries={}
    G.currentContext=nil; G.skillSignature=nil; G.episode=nil; G.recovery=nil
    G.context("start")
    -- Starting in combat cannot reconstruct the game's start boundary.
    if UnitAffectingCombat("player") then s.started_in_combat=true end
end
function G.fightOpen(r)
    r.skills_engage=G.skills()
    r.context_engage=G.currentContext; r.hp_engage=hp(); r.rage_engage=rage()
    r.dmg_out=0; r.overkill_out=0; r.dmg_in=0; r.blocked_in=0; r.absorbed_in=0
    r.outcomes_out={}; r.outcomes_in={}; r.spells={}
    if G.episode then G.attachEpisode(r) else r.flags.episode_unavailable=true end
end
function G.attachEpisode(r)
    local e=G.episode
    if not e or r.episode then return end
    -- GUID references consume budget even though the episode is still open.
    if not G.reserve({},512) then return end
    r.episode=e.id; r.flags.episode_unavailable=nil
    e.record_ids=e.record_ids or {}; e.record_ids[#e.record_ids+1]=r.record_id
    local seen=false; for _,guid in ipairs(e.guids) do if guid==r.guid then seen=true end end
    if not seen then e.guids[#e.guids+1]=r.guid end
    e.multi=#e.guids>1
    if e.multi then
        r.flags.multi_engaged=true
        for _,guid in ipairs(e.guids) do
            if G.byGuid[guid] and not G.byGuid[guid].t_end then G.byGuid[guid].flags.multi_engaged=true end
        end
    end
end
function G.fightClose(r,reason)
    if r.t_end then return end
    local sk=G.skills()
    if G.json(sk)~=G.json(r.skills_engage) then r.skills_end=sk; r.flags.skill_changed_midfight=true end
    r.t_end=G.now(); r.close_reason=reason; r.context_end=G.currentContext
    r.hp_end=hp(); r.rage_end=rage()
    if r.context_end~=r.context_engage then r.flags.context_changed_midfight=true end
end
local function count(t,k) t[k]=(t[k] or 0)+1 end
local function bucket(t,key,cap)
    if not t[key] then
        local n=0; for k in pairs(t) do if k~="other" then n=n+1 end end
        if n>=cap then key="other" end
        t[key]=t[key] or {n=0,dmg=0}
    end
    return t[key]
end
local function healing(o,v)
    local amount,over=v[15],v[16]
    if type(amount)~="number" then return end
    over=type(over)=="number" and over or 0
    local effective=math.max(0,amount-over)
    o.heal_in=o.heal_in+effective; o.overheal_in=o.overheal_in+over
    local b=bucket(o.heals,v[12],6); b.n=b.n+1; b.heal=(b.heal or 0)+effective; b.dmg=nil
    b.overheal=(b.overheal or 0)+over
end
function G.weaponCombat(v)
    if not G.session or G.closing then return end
    local event,source,dest=v[2],v[4],v[8]
    if event=="UNIT_DIED" and dest==G.player then G.weaponDeath(); return end
    if event=="SPELL_HEAL" or event=="SPELL_PERIODIC_HEAL" then
        local target=G.byGuid[dest]
        if target and not target.t_end then target.flags.external_heal=true end
    end
    if (event=="SPELL_HEAL" or event=="SPELL_PERIODIC_HEAL") and dest==G.player then
        if G.episode then healing(G.episode,v) end
        if G.recovery then healing(G.recovery,v) end
        if source~=G.player and source~=UnitGUID("pet") then
            if G.episode then G.episode.external_heal=true end
            if G.recovery then G.recovery.external_heal=true end
            for _,r in pairs(G.live) do if not r.t_end then r.flags.external_heal=true end end
        end
        return
    end
    if event=="SPELL_AURA_APPLIED" and dest==G.player and G.recovery then
        local a=bucket(G.recovery.auras,v[12],8); a.n=a.n+1
        -- Overflow bucket deliberately has no misleading last-spell name.
        if G.recovery.auras[v[12]]==a then a.name=G.clip(v[13],120) end
        return
    end
    local outgoing=source==G.player or (source and source==UnitGUID("pet"))
    local incoming=dest==G.player
    local r=outgoing and G.byGuid[dest] or incoming and G.byGuid[source]
    if not r or r.t_end then return end
    local damage=event=="SWING_DAMAGE" or event=="RANGE_DAMAGE" or event:match("^SPELL.*_DAMAGE$")
    local missed=event=="SWING_MISSED" or event=="RANGE_MISSED" or event:match("^SPELL.*_MISSED$")
    if not damage and not missed then return end
    local offset=event:match("^SWING_") and 0 or 3
    local counters=outgoing and r.outcomes_out or r.outcomes_in
    local dealt=0
    if damage then
        local amount=v[12+offset]; if type(amount)~="number" then return end
        local over=math.max(0,tonumber(v[13+offset]) or 0)
        local blocked=tonumber(v[16+offset]) or 0; local absorbed=tonumber(v[17+offset]) or 0
        count(counters,"hit")
        if v[18+offset] then count(counters,"crit") end
        if outgoing then
            dealt=math.max(0,amount-over); r.dmg_out=r.dmg_out+dealt; r.overkill_out=r.overkill_out+over
            if v[19+offset] then count(counters,"glancing") end
            if blocked>0 then count(counters,"block") end
        else
            r.dmg_in=r.dmg_in+amount; r.blocked_in=r.blocked_in+blocked; r.absorbed_in=r.absorbed_in+absorbed
            if blocked>0 and amount>0 then count(counters,"block_partial") end
            if v[20+offset] then count(counters,"crushing") end
            if G.episode then G.episode.dmg_in=G.episode.dmg_in+amount end
        end
    else
        local kind=v[12+offset]; local amount=tonumber(v[14+offset]) or 0
        local key=({MISS="miss",DODGE="dodge",PARRY="parry",BLOCK=outgoing and "block" or "block_full",EVADE="evade",ABSORB="absorb",RESIST="resist",IMMUNE="immune"})[kind] or "other_miss"
        count(counters,key)
        if not outgoing then
            if kind=="BLOCK" then r.blocked_in=r.blocked_in+amount end
            if kind=="ABSORB" then r.absorbed_in=r.absorbed_in+amount end
        end
    end
    if outgoing and offset==3 and type(v[12])=="number" then
        local b=bucket(r.spells,v[12],12); b.n=b.n+1; b.dmg=b.dmg+dealt
    end
end
function G.recoveryClose(outcome)
    local r=G.recovery; if not r then return end
    r.t_end=G.now(); r.hp_end=hp(); r.outcome=outcome
    r.hp_net_gain=r.hp_end-r.hp0; r.unlogged_gain=r.hp_net_gain-r.heal_in
    if outcome=="full" then r.t_full=r.t_end end
    if outcome=="interrupted_by_combat" then r.hp_at_next_engage=r.hp_end end
    G.recovery=nil; G.seal(r)
end
function G.healthChanged()
    if G.recovery and hp()>=UnitHealthMax("player") then G.recoveryClose("full") end
end
function G.episodeClose(reason)
    local e=G.episode; if not e then return end
    e.t_end=G.now(); e.hp_end=hp(); e.rage_end=rage(); e.close_reason=reason
    e.hp_unexplained=math.max(0,(e.hp_start-e.hp_end)-e.dmg_in+e.heal_in)
    for _,guid in ipairs(e.guids) do
        local r=G.byGuid[guid]
        if r and not r.t_end then
            r.flags.incomplete=true; G.fightClose(r,reason)
        end
    end
    G.episode=nil; G.seal(e)
end
function G.combatStart()
    if G.closing or G.episode then return end
    G.recoveryClose("interrupted_by_combat")
    local e={id=#G.session.episodes+1,t_start=G.now(),hp_start=hp(),rage_start=rage(),
        guids={},multi=false,paused=G.paused and true or false,dmg_in=0,heal_in=0,overheal_in=0,heals={}}
    if not G.append(G.session.episodes,e,12000) then return end
    G.episode=e
    -- CLEU may reach us just before the regen event in the same client frame.
    for _,r in pairs(G.live) do if not r.t_end and not r.episode then G.attachEpisode(r) end end
end
function G.combatEnd()
    if G.closing then return end
    local e=G.episode; G.episodeClose("combat_end")
    if not e or G.paused or UnitIsDeadOrGhost("player") then return end
    local r={t0=G.now(),hp0=hp(),hp_max=UnitHealthMax("player"),start_level=UnitLevel("player"),episode=e.id,
        context=G.currentContext,heal_in=0,overheal_in=0,heals={},auras={}}
    if G.append(G.session.recoveries,r,16000) then G.recovery=r; G.healthChanged() end
end
function G.weaponDeath()
    if G.episode then G.episode.player_died=true end
    for _,r in pairs(G.live) do if not r.t_end then r.flags.player_died=true; G.fightClose(r,"death") end end
    G.episodeClose("death"); G.recoveryClose("death")
end
function G.weaponPause()
    if G.episode then G.episode.paused=true end
    G.recoveryClose("paused")
end
function G.weaponStop()
    G.episodeClose("stopped"); G.recoveryClose("stopped")
    for _,r in pairs(G.live) do G.fightClose(r,"stopped") end
end
local function median(values)
    table.sort(values); local n=#values
    if n>0 then return (values[math.floor((n+1)/2)]+values[math.ceil((n+1)/2)])/2 end
end
function G.weaponSummary(s,q,clean)
    if s.record_schema~=2 and s.record_schema~=3 then return end
    local contexts={}; q.weapon_contexts={}
    for _,c in ipairs(s.contexts) do contexts[c.id]={context=c.id,clean_kills=0,ttk={},recovery={},out=0,inc=0,n=0} end
    for _,r in ipairs(clean) do
        local c=contexts[r.context_engage]
        if c then
            c.clean_kills=c.clean_kills+1; c.ttk[#c.ttk+1]=r.t_death-r.t_engage
            if r.dmg_out~=nil and r.dmg_in~=nil then c.out=c.out+r.dmg_out; c.inc=c.inc+r.dmg_in; c.n=c.n+1 end
        end
    end
    for _,r in ipairs(s.recoveries) do
        local c=contexts[r.context]
        if c and r.outcome=="full" and not r.context_changed and not r.external_heal then c.recovery[#c.recovery+1]=r.t_full-r.t0 end
    end
    for _,context in ipairs(s.contexts) do
        local c=contexts[context.id]
        q.weapon_contexts[#q.weapon_contexts+1]={context=c.context,clean_kills=c.clean_kills,median_ttk=median(c.ttk),
            mean_dmg_out=c.n>0 and c.out/c.n or nil,mean_dmg_in=c.n>0 and c.inc/c.n or nil,
            median_full_recovery=median(c.recovery),full_recoveries=#c.recovery}
    end
end
function G.weaponReport(q)
    local s=G.db.sessions[#G.db.sessions]
    local groups,order={},{}
    for _,c in ipairs(s.contexts or {}) do
        local key=G.weaponIdentity(c.items)
        if not groups[key] then groups[key]={ids={},kills=0,out=0,inc=0,ttk={}}; order[#order+1]=key end
        groups[key].ids[c.id]=true
    end
    for _,key in ipairs(order) do
        local b=groups[key]
        for _,r in ipairs(s.records) do
            if b.ids[r.context_engage] and r.t_death and r.xp_total and not r.flags.multi_engaged then
                local bad=false
                for _,f in ipairs(G.exclusions) do if r.flags[f] then bad=true end end
                if not bad then
                    b.kills=b.kills+1; b.out=b.out+(r.dmg_out or 0); b.inc=b.inc+(r.dmg_in or 0)
                    b.ttk[#b.ttk+1]=r.t_death-r.t_engage
                end
            end
        end
    end
    local limit=s.stop_reason=="storage_cap" and 3 or 4
    for i=1,math.min(limit,#order) do
        local b=groups[order[i]]
        G.say(string.format("Weapon set %d: %d clean; median TTK %s; mean damage out/in %s/%s.",i,b.kills,
            median(b.ttk) and string.format("%.2fs",median(b.ttk)) or "n/a",
            b.kills>0 and string.format("%.2f",b.out/b.kills) or "n/a",b.kills>0 and string.format("%.2f",b.inc/b.kills) or "n/a"))
    end
    if #order>limit then G.say("Additional weapon sets and full context detail are in Export.") end
end
