local _,G=...
if not G.enabled then return end
function G.weaponIdentity(items)
    local out={}
    for slot=16,18 do
        local link=items and items[slot] and items[slot].link
        local raw=link and link:match('item:([^|]+)')
        if raw then
            local fields={}; for field in (raw..':'):gmatch('(.-):') do fields[#fields+1]=field end
            fields[9]='0' -- linkLevel; keep item, enchant, gems, suffix and unique ID
            out[slot]=table.concat(fields,':')
        else out[slot]='missing' end
    end
    return G.json(out)
end
local function state()
    local b,p,n=UnitAttackPower('player'); local _,armor=UnitArmor('player')
    local x={ap=b and b+(p or 0)+(n or 0),armor=armor,maxHP=UnitHealthMax('player'),level=UnitLevel('player')}
    if UnitBuff then
        x.battle_shout=false
        for i=1,40 do
            local name=UnitBuff('player',i); if not name then break end
            if name=='Battle Shout' then x.battle_shout=true end
        end
    else x.battle_shout_unavailable=true end
    return x
end
function G.diagnostic(reason,guid)
    if not G.session then return end
    local d=G.session.diagnostics
    d.counts[reason]=(d.counts[reason] or 0)+1
    if #d.samples<20 then d.samples[#d.samples+1]={t=G.now(),reason=reason,guid=guid} end
end
local start=G.weaponStart
function G.weaponStart()
    start(); G.session.diagnostics={counts={},samples={}}; G.session.player_deaths=0
    G.bytes=G.bytes+12000 -- diagnostics + added summaries, bounded per session
    G.deathLatched=false; G.previousEpisode=nil; G.levelPending=nil
end
local engage=G.engage
function G.engage(guid,name,t)
    local old=G.byGuid[guid]
    if old and old.t_end then G.diagnostic('closed_guid_reengagement',guid) end
    local r=engage(guid,name,t)
    if not r then G.diagnostic(G.capacityClosing and 'capacity' or 'no_record',guid) end
    return r
end
local open=G.fightOpen
function G.fightOpen(r) open(r); r.state_engage=state() end
local close=G.fightClose
function G.fightClose(r,reason)
    if not r.t_end then r.state_end=state() end
    close(r,reason)
end
local death=G.weaponDeath
function G.weaponDeath()
    if not G.deathLatched then G.session.player_deaths=G.session.player_deaths+1; G.deathLatched=true end
    death()
end
local combatStart=G.combatStart
function G.combatStart()
    if not UnitIsDeadOrGhost('player') then G.deathLatched=false end
    if G.previousEpisode then G.previousEpisode.time_to_next_pull_after_death=G.previousEpisode.player_died or G.previousEpisode.close_reason=="death" or nil; G.previousEpisode.time_to_next_pull=G.now()-G.previousEpisode.t_end; G.previousEpisode=nil end
    combatStart()
end
local episodeClose=G.episodeClose
function G.episodeClose(reason)
    local e=G.episode
    if e then
        e.combat_duration=G.now()-e.t_start
        e.empty=#e.guids==0; e.critter_only=#e.guids>0
        for _,guid in ipairs(e.guids) do
            local r=G.byGuid[guid]
            if not r or r.creature_type~='Critter' then e.critter_only=false end
        end
        -- Missing unit type is unclassified, never inferred from level.
        if e.empty then G.diagnostic('empty_episode') end
    end
    episodeClose(reason)
    if e then G.previousEpisode=e end
end
local combatEnd=G.combatEnd
function G.combatEnd()
    local e=G.episode; combatEnd()
    local r=G.session.recoveries[#G.session.recoveries]
    if r and e and r.episode==e.id then
        r.category=e.empty and 'empty_episode' or e.critter_only and 'known_critter' or r.hp0>=r.hp_max and 'already_full' or e.dmg_in>0 and 'post_damage' or 'unclassified'
        r.healing_attribution='unknown_except_logged_evidence'
    end
end
local recoveryClose=G.recoveryClose
function G.recoveryClose(outcome)
    local r=G.recovery
    if r then
        r.level_up_refill=r.level_up_refill or G.levelPending~=nil or (r.start_level and UnitLevel('player')>r.start_level) or nil
        if outcome=='full' then r.time_to_full=G.now()-r.t0 end
    end
    recoveryClose(outcome)
end
local context=G.context
function G.context(reason,level)
    if reason=='level' then
        G.levelPending={t=G.now(),level=level}
        if G.recovery then G.recovery.level_up_refill=true end
        return
    end
    context(reason,level)
end
local tick=G.tick
function G.tick()
    if G.levelPending and G.now()-G.levelPending.t>=0.3 and UnitLevel('player')>=G.levelPending.level then
        local p=G.levelPending; G.levelPending=nil; context('level',p.level)
        local c=G.session and G.session.contexts[#G.session.contexts]
        if c then c.level_event_t=p.t; c.stats_sample_t=G.now() end
    end
    tick()
end
local summary=G.summary
function G.summary(s)
    local q=summary(s)
    if not s.diagnostics then return q end
    q.player_deaths=s.player_deaths -- legacy absent remains unavailable
    q.flagged_records=q.reasons
    q.all_award_base=0; q.all_award_rested=0; q.unclassified_award_xp=0; q.matched_award_xp=0; q.unmatched_award_xp=0
    for _,a in ipairs(s.awards) do
        if not a.paused and not a.after_stop then
            if a.base~=nil and a.rested~=nil then q.all_award_base=q.all_award_base+a.base; q.all_award_rested=q.all_award_rested+a.rested
            else q.unclassified_award_xp=q.unclassified_award_xp+(a.total or 0) end
            if a.match and a.match~='unmatched' and a.match~='ambiguous' then q.matched_award_xp=q.matched_award_xp+(a.total or 0)
            else q.unmatched_award_xp=q.unmatched_award_xp+(a.total or 0) end
        end
    end
    q.xp_scope='xp_actual: unpaused kill awards including unmatched; xp_base/rested: clean singles only; all_award_*: same scope as xp_actual; unknown modifiers in unclassified_award_xp; non-kill XP excluded; all rates use unpaused session.elapsed seconds'
    q.all_award_base_per_min=s.elapsed>0 and q.all_award_base*60/s.elapsed or 0
    return q
end

local observe=G.observe
function G.observe(unit)
    observe(unit)
    local r=G.live and G.live[UnitGUID(unit)]
    if r and UnitCreatureType then r.creature_type=UnitCreatureType(unit) end
end
local sample=G.sampleXP
function G.sampleXP()
    local before=G.baseline; sample()
    if G.session and before~=G.baseline then
        local delta=G.delta(before,G.baseline)
        if delta then G.session.observed_character_xp=(G.session.observed_character_xp or 0)+delta end
    end
end
local finalSummary=G.summary
function G.summary(s)
    local q=finalSummary(s)
    if s.diagnostics then
        q.observed_character_xp=s.observed_character_xp
        q.character_xp_scope='debounced valid XP deltas, includes paused/non-kill gains; unobserved/coalesced changes can limit attribution'
        q.orphan_awards=0
        for _,a in ipairs(s.awards) do if a.match=='unmatched' then q.orphan_awards=q.orphan_awards+1 end end
    end
    return q
end
