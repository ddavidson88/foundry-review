ForeverGrindProbe 0.1.0-era.10 — independent review candidate, NOT INSTALLED
Addresses cLaunchPrep full review 1flbBI84yyqBcV3BJ7U2kLswZ6Q3ytACe.
Base era9 REVIEW ce84e0f6250bf95fe36796ead044966b7dd4c22e9ff494aa39235f270bca90c9.

B1 reproduced BEFORE fix: hit/close/re-pull produced one record, failing required
regression. Now closed GUID opens a new record_id (session sequence), byGuid/live
point to latest, prior record retained. Episode record_ids added; guids deduped.
Closed records no longer counted as currently overlapping. Retired record
reservations retained for5s settlement then sealed, never mutate new live mapping.
XP matcher still uses unique name/death window; award.record_id identifies exact
matched encounter, award.match remains GUID for compatibility. No GUID guessing.
Tests verify earlier record unchanged during repull, new outgoing damage20,
combat-end-before-death XP on new record, and old/new retained.
This demonstrates a code defect and fix, not a native replay of episodes76/94/96.

N1: removed Stopped settling chat. Manual Stop <=6 lines (total +4 sets +overflow).
Storage cap uses3 sets so cap message +total +3 sets +overflow remains <=6.
N2: cache duplicates serialized session text; long sessions intentionally fall
back to summary/first page while full sessions remain intact. Reviewer estimate:
257KB/99kills ~2.6KB/kill; full cache threshold ~750KB (~290kills) before overhead.
These are rough unmeasured estimates; actual conservative accounting may fall
back earlier. No new storage policy; no session deletion or truncation.
N3: recovery start_level now set at open. Preserve already observed level-up flag.
N4: episode.time_to_next_pull_after_death explicitly labels death-spanning gap.
N5: logout saves only if latest session has no matching cache; active finish
already saves. Tests exercise both logout handler orders (one export build).

77 emulated Lua5.1 tests pass. Native checks still pending; no new owner run
requested. DBschema1/record_schema3 retained. Old sessions readable. Collector
file names unchanged; native collection not tested. No installer supplied.
Expected handoff: exact ZIP hashes, public GitHub commit, Claude review.

Prior reference, superseded where noted above:
ForeverGrindProbe era.9 REVIEW CANDIDATE, not installed/cleared.
Base era.8 SHA256 fc4d5d7569cc10388ac61857c0a25bcfd7e2e599d95055d0795622a0b17b6e1a.
Scope: 1a0MNRUjegSMtSZDE2VJf-gwx0e4Lmd74 and WarriorEV refinement note.
1. Diagnostics bounded to reason counters +20 samples; empty episodes and
closed-GUID reengagement surfaced. Reproduced existing closed-GUID rejection;
kept records unchanged, no guessed GUID or claim that native missing encounters
are fixed. Unmatched awards retain name/raw message/time/XP; orphan count added.
2. player_deaths latch counts repeated death callbacks once, reset next living
combat start; record flags separately labeled flagged_records. Native five-death
session not replayed. Multi-mob synthetic test counts one death/two flags.
3. Existing numeric block offsets audited, unchanged. Existing tests cover
partial/full block values4/7/9, spell offsets, outgoing block outcomes. Native
33 one-point blocks cannot be confirmed without combatlog.
4. Preserve clean-only xp_base/rested. Add all_award_base/rested, unclassified,
matched/unmatched totals, observed_character_xp including non-kill/paused gains.
Explicit scope labels; observed character delta is not proof of quest attribution.
Base-rate denominator session.elapsed unpaused seconds. Unknown parsing visible.
5. Episode combat_duration and time_to_next_pull separately; recovery time_to_full,
category, net HP retained. Already full, empty, observed Critter, post-damage and
unclassified categories. Level refill flagged; no passive-regen attribution.
6. Fresh per-fight state_engage/end: AP,armor,maxHP,level,Battle Shout presence
via English UnitBuff scan, or explicit unavailable. Level event coalesces at
>=0.3s and UnitLevel readiness, stores event/sample times. This does not prove
native stat propagation complete; event-order verification remains pending.
7. Weapon keys remove linkLevel field9, retain item/enchant/gem/suffix/unique ID;
underlying clean fights pooled directly, sample sizes printed; no median of
medians. Context and per-fight levels/skills/mob IDs retained.

record_schema3 stays readable, DBschema1 unchanged. No per-swing timeline.
Bloat: two small state tables typically <400 compact JSON bytes per fight,
conservative storage estimate roughly1.5KB plus optional unit type. Existing
24KB record reservation retained. Additional12000B/session reserve for bounded
diagnostics and summaries. Exact overhead depends on numeric/string lengths.

74 emulated tests pass; no native claims, no new owner test requested. Existing
collect filenames retained. Era.8 review still pending; findings apply as addendum.
Public era.8 transfer now available: branch grindprobe-era8-review, commit
5e71390a6118b2962933a06d4babef9f98e208a9 in ddavidson88/foundry-review;
ZIPs and hashes under grindprobe/era8/. Owner explicitly approved public upload.

Prior reference:
ForeverGrindProbe 0.1.0-era.8 — REVIEW CANDIDATE, NOT INSTALLED

Combined handoffs: 1LzORxR7gMdUB9ZY5bWAEodstTHPEWpSe and
1fHXvpDqFHJft-5AtxYoaz_vabWezJZ-s. Baseline exact era.7 REVIEW
SHA256 e86cf45869b5ac3dff8c2dc075127cc3c7d7bda17668eddaf8cf86d8863e7d7e.

Export always opens after Stop settles. Pages have <=16000 payload bytes,
UTF-8-safe boundaries, session id, page n/N, total/payload byte counts. Strip
first header line and concatenate payloads in order to reconstruct full JSON.
Prev/Next preselect text and focus; Press Ctrl+C instruction. No clipboard API
claim and no raw chat dump. Existing panel size/buttons unchanged.

Skill events no longer create contexts. Fight skills_engage and optional
skills_end retain weapon/Defense rank/max. Skill differences informational;
gear/level contexts retained. DB schema1, new record_schema3; schema2 readable.
Stop prints totals plus up to4 weapon-set lines and optional overflow note
(max6 lines at settlement). Aggregation uses slot16/17/18 links across contexts.
Full context summary stays in export. Existing exclusion details remain in data.

Stop settlement and PLAYER_LOGOUT build db.last_export, record_schema3,
session_id,built_utc (Unix seconds), pages,total_pages,compact summary,complete.
Cache is replaced, not accumulated; discarded when starting next recording.
Conservative running-byte estimate bounds it against 1.5MB. If full copy does
not fit: summary + first page, complete=false and explanatory note. Exceptional
pressure can shorten that page, explicitly first_page_truncated=true. This is
an emergency fallback beyond the requested summary+first-page behavior; normal
64KiB headroom fits the 16KiB first page. Full sessions are never truncated.
No window or chat on logout. Idle logout also caches latest session. Stop
prepares in-memory SavedVariables after the 3.2s XP settlement; WoW persists
to disk on logout/reload, not immediately on clicking Stop.

Same ForeverGrindProbe.lua/.bak filenames and variable. Existing collect script
requires no change. Exact collect-script native byte comparison NOT performed
here; owner-side PS7/client execution remains pending. Do not claim native
acceptance or native combat-log cross-check. Constructed Lua5.1 fixtures only.

68 tests pass, including 50KB/257KB/600KB paged reassembly, page focus/selection,
no chat dump, active logout silence and reload, repeat-cache accounting,
capacity fallback, skill storm and summary cap, schema2 export. Prior tests
updated only for intentionally superseded behavior. tests/RESULTS.txt included.
Source docs, manifest, tests and deterministic BUILD.py included for review.
Claude owns clearance/install; no installation done. Probe and guide untouched.

Prior era.7 reference (era.8 behavior above supersedes conflicting export/skill details):
ForeverGrindProbe 0.1.0-era.7 — REVIEW CANDIDATE, NOT CLEARED FOR INSTALL

Same addon and saved-variable name as era.5. DB schema remains 1; new sessions
carry record_schema=2. Existing data stays readable. ForeverRouteProbe untouched.

Start, play, Pause/Resume for breaks, Stop, wait 3.2 seconds, Export. No typing
required. The draggable always-visible panel remains 286 x 116 at 65% scale.
No auto-start, combat-log toggle, installation, reset or deletion.
Optional commands: /grind start <label> | pause | resume | stop | export
/grind mark <note> remains available without any panel typing box.

Era only: interfaces 11500–11599; inert on Forever. English enUS/enGB XP parser
and weapon/Defense skill names. Start out of combat for weapon comparisons.

Captures change-driven gear/skill contexts, per-mob damage/defense outcomes,
game-bounded combat episodes and event-driven recovery intervals. No raw combat
stream, item-cache dependency, regen/armor/rage model or weapon recommendation.
See SCHEMA.txt for field semantics and unavailable values.
Stop prints the existing XP/min summary plus one line per context: clean kills,
median TTK, mean damage out/in, median full recovery. n/a means unavailable.
Skill-ups can create multiple contexts for the same weapon; group offline.
Keep normal recovery/loot/movement timed; pause only for breaks. Recovery is
combat end to full HP/next fight, not inferred food, travel or idle time.
Use a new test for level-specific sustained rates. XP/min includes rested.
Era results are directional only for Forever, not launch forecasts.

Export is FULL latest-session JSON; numeric table keys become string keys.
Above 200,000 bytes the window refuses with saved-file instructions; nothing
is truncated/deleted. Log out normally, then copy the per-character file:
 WTF/Account/<account>/<realm>/<character>/SavedVariables/ForeverGrindProbe.lua
Keep its .bak too. All sessions are in that file. Archive while WoW is closed
before manual reset. This standalone recorder has no account tripwire.

Caps retained: 2,000 mob records per character, 50 sessions, 100 notes per
session, 2,000 XP awards, 100 pending awards; conservative byte estimate below
1.5 MB with 64 KiB finish headroom. Byte cap may stop well before 2,000 kills.
Cap stop says so in chat. One DB size walk at load; bounded reservations and
one size estimate per closed object replace the old per-second DB walk.

Limits: mob level requires observed unit; no XP-formula inference. External
interference can only be detected after engagement. Ambiguous deaths/XP state
remain excluded. Thirty seconds without action is an evade/flee proxy.
A test begun during combat cannot reconstruct the missing episode start;
flags.episode_unavailable identifies those fights. HP snapshots follow APIs
at callback time; native event ordering still needs cross-checking.

AFTER CLAUDE CLEARANCE ONLY: Claude supplies PS7 installer with era.5 backup.
Native acceptance: manually /combatlog; Start out of combat with 1H+shield,
kill a few mobs, swap to staff out of combat, kill a few more, include a full
recovery and Pause/Resume, Stop/Export. Claude compares damage/blocks against
advanced logging. Recorder acceptance only, not the weapon verdict.

Tests: python -m unittest discover -s tests -v (Python + lupa Lua 5.1).
Build: python BUILD.py. Deterministic ZIPs and manifest in dist/.
62 emulated tests pass. Native Era CLEU tuples were not located in available
saved runs; combat fixtures are constructed Era-layout inputs, NOT native
replay. Verbatim native rested XP string remains tested. See REVIEW.txt.
