local _,G=...
if not G.enabled then return end
function G.exportText()
    if not G.db then G.load() end
    if not G.db then return end
    local s=G.db.sessions[#G.db.sessions]
    if not s then G.say("No tests recorded."); return end
    return G.json({schema=1,kind="ForeverGrindProbe",session=s,field_notes={
        units="seconds; HP/damage/healing in health points; rage in displayed rage units; chances in percent",
        clock="GetTime seconds; session.started anchored by wall_start (GetServerTime Unix seconds)",
        missing="absent = unavailable; items[].missing means no link, not item 0",
        hp_unexplained="max(0, hp_start-hp_end-dmg_in+heal_in); residual, not proof of Bloodrage",
        recovery="combat end to full HP/next fight; unlogged_gain is net HP gain minus logged healing, not modeled regen",
        counts="hit includes crit/glancing/crushing/partial blocks; those counts overlap",
        legacy="DB schema 1; record_schema absent is legacy; never interpret absent combat fields as zero"}})
end
function G.export()
    if G.session then G.say("Stop the test and wait for the summary before exporting."); return end
    local text=G.exportText(); if not text then return end
    if not G.exportFrame then
        local f=CreateFrame("Frame",nil,UIParent,"BasicFrameTemplateWithInset")
        f:SetSize(700,450); f:SetPoint("CENTER"); f.TitleText:SetText("Grind Probe — Press Ctrl+C")
        local scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",12,-34); scroll:SetPoint("BOTTOMRIGHT",-32,45)
        local box=CreateFrame("EditBox",nil,scroll)
        box:SetMultiLine(true); box:SetFontObject(ChatFontNormal); box:SetWidth(640)
        box:SetAutoFocus(false); box:SetMaxLetters(0); box:SetScript("OnEscapePressed",function() f:Hide() end)
        scroll:SetScrollChild(box); f.box=box; G.exportFrame=f
        for i,name in ipairs({"Prev","Next"}) do
            local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
            b:SetSize(80,24); b:SetPoint("BOTTOMLEFT",12+(i-1)*90,10); b:SetText(name)
            b:SetScript("OnClick",function() G.showPage(f.page+(i==1 and -1 or 1)) end)
        end
    end
    G.exportFrame.pages=G.pages(text); G.showPage(1)
end
SLASH_FOREVERGRINDPROBE1="/grind"
SlashCmdList.FOREVERGRINDPROBE=function(msg)
    local cmd,rest=msg:match("^(%S*)%s*(.-)%s*$"); cmd=cmd:lower()
    if cmd=="start" then
        if GetLocale()~="enUS" and GetLocale()~="enGB" then G.say("Candidate supports English XP messages only; recording not started."); return end
        G.start(rest)
    elseif cmd=="pause" then G.pause()
    elseif cmd=="resume" then G.resume()
    elseif cmd=="stop" then G.stop()
    elseif cmd=="mark" then
        if G.session and not G.closing and #G.session.marks<100 then
            local m={t=G.now(),note=G.clip(rest,512)}
            if G.append(G.session.marks,m,4096) then G.seal(m); G.say("Mark saved.") end
        else G.say("No active test, or mark cap reached.") end
    elseif cmd=="export" then G.export()
    else G.say("/grind start <species / gear label> | pause | resume | stop | mark <note> | export") end
end

-- The lightweight panel lives separately from the opt-in capture frame.
-- It never calls start on login, reload, or refresh.
local function timeText(seconds)
    seconds=math.floor(math.max(0,seconds or 0))
    return string.format("%02d:%02d",math.floor(seconds/60),seconds%60)
end
function G.refreshPanel()
    local f=G.panel; if not f then return end
    local s=G.session
    local last=G.db and G.db.sessions[#G.db.sessions]
    local status,r,g,b="Idle",0.8,0.8,0.8
    if not G.db then status,r,g,b="Data blocked",1,0.3,0.3
    elseif s and G.closing then status,r,g,b="Finishing…",0.6,0.8,1
    elseif s and G.paused then status,r,g,b="Paused",1,0.8,0.2
    elseif s then status,r,g,b="Recording",0.3,1,0.4 end
    f.status:SetText(status); f.status:SetTextColor(r,g,b)
    local shown=s or last
    local elapsed=shown and shown.elapsed or 0
    if s and not G.paused and not G.closing then elapsed=elapsed+math.max(0,G.now()-G.lastTick) end
    local kills=0
    if shown then for _,record in ipairs(shown.records) do if record.t_death then kills=kills+1 end end end
    f.stats:SetText((s and "" or (last and "Last: " or ""))..timeText(elapsed).."  |  "..kills.." kills")
    f.start:SetEnabled(G.db~=nil and s==nil)
    f.pause:SetEnabled(s~=nil and not G.closing)
    f.pause:SetText(G.paused and s and "Resume" or "Pause")
    f.stop:SetEnabled(s~=nil and not G.closing)
    f.export:SetEnabled(G.db~=nil and last~=nil and s==nil)
end
function G.savePanelPosition()
    if not G.panel or not G.db then return end
    local point,_,relativePoint,x,y=G.panel:GetPoint(1)
    G.db.ui=G.db.ui or {}
    G.db.ui.position={point=point,relativePoint=relativePoint,x=x,y=y}
end
function G.createPanel()
    if G.panel then return end
    if not G.db then G.load() end
    local f=CreateFrame("Frame","ForeverGrindProbePanel",UIParent,"BackdropTemplate")
    G.panel=f
    f:SetSize(286,116); f:SetScale(0.65); f:SetFrameStrata("MEDIUM")
    f:SetClampedToScreen(true); f:SetMovable(true); f:EnableMouse(true)
    f:SetBackdrop({bgFile="Interface\\Tooltips\\UI-Tooltip-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
        tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
    f:SetBackdropColor(0.04,0.04,0.06,0.92)
    local anchors={TOPLEFT=true,TOP=true,TOPRIGHT=true,LEFT=true,CENTER=true,RIGHT=true,BOTTOMLEFT=true,BOTTOM=true,BOTTOMRIGHT=true}
    local p=G.db and G.db.ui and G.db.ui.position
    if type(p)=="table" and anchors[p.point] and anchors[p.relativePoint]
        and type(p.x)=="number" and type(p.y)=="number" and math.abs(p.x)<10000 and math.abs(p.y)<10000 then
        f:SetPoint(p.point,UIParent,p.relativePoint,p.x,p.y)
    else f:SetPoint("TOPLEFT",UIParent,"TOPLEFT",30,-180) end

    local title=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    title:SetPoint("TOPLEFT",10,-9); title:SetText("Grind Probe  •  drag here")
    local drag=CreateFrame("Frame",nil,f)
    drag:SetPoint("TOPLEFT",4,-4); drag:SetPoint("TOPRIGHT",-4,-4); drag:SetHeight(22)
    drag:EnableMouse(true); drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart",function() f:StartMoving() end)
    drag:SetScript("OnDragStop",function() f:StopMovingOrSizing(); G.savePanelPosition() end)
    f.drag=drag
    f.status=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    f.status:SetPoint("TOPLEFT",10,-31)
    f.stats=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    f.stats:SetPoint("TOPRIGHT",-10,-33)

    local function button(text,width,x,y,action)
        local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
        b:SetSize(width,24); b:SetPoint("TOPLEFT",x,y); b:SetText(text)
        b:SetScript("OnClick",function()
            action(); G.refreshPanel()
        end)
        return b
    end
    f.start=button("Start",84,10,-53,function()
        local label=string.format("%s L%d @ %s",UnitName("player") or "Player",UnitLevel("player") or 0,tostring(GetServerTime()))
        SlashCmdList.FOREVERGRINDPROBE("start "..label)
    end)
    f.pause=button("Pause",84,101,-53,function()
        SlashCmdList.FOREVERGRINDPROBE(G.paused and "resume" or "pause")
    end)
    f.stop=button("Stop",84,192,-53,function() SlashCmdList.FOREVERGRINDPROBE("stop") end)
    f.export=button("Export last test",266,10,-82,function() SlashCmdList.FOREVERGRINDPROBE("export") end)
    local elapsed=0
    f:SetScript("OnUpdate",function(_,dt)
        elapsed=elapsed+dt
        if elapsed>=0.25 then elapsed=0; G.refreshPanel() end
    end)
    f:Show(); G.refreshPanel()
end
local panelLoader=CreateFrame("Frame")
G.panelLoader=panelLoader
panelLoader:RegisterEvent("PLAYER_LOGIN")
panelLoader:SetScript("OnEvent",function(self)
    self:UnregisterEvent("PLAYER_LOGIN"); G.createPanel()
end)

-- Pages reassemble by stripping the first header line and joining payloads.
function G.pages(text)
    local size=16000; local pages,chunks={},{}; local start=1
    while start<=#text do
        local last=math.min(#text,start+size-1)
        while last<#text and text:byte(last+1)>=128 and text:byte(last+1)<192 do last=last-1 end
        chunks[#chunks+1]=text:sub(start,last); start=last+1
    end
    if #chunks==0 then chunks[1]="" end
    local session=G.db.sessions[#G.db.sessions]
    for i,chunk in ipairs(chunks) do
        pages[i]=string.format("ForeverGrindProbe session=%s page=%d/%d total_bytes=%d chunk_bytes=%d\n",session.id,i,#chunks,#text,#chunk)..chunk
    end
    return pages
end
function G.showPage(i)
    local f=G.exportFrame; i=math.max(1,math.min(i,#f.pages)); f.page=i
    f:Show(); f.TitleText:SetText(string.format("Page %d of %d — Press Ctrl+C",i,#f.pages))
    f.box:SetText(f.pages[i]); f.box:SetFocus(); f.box:HighlightText()
end
function G.dropExport()
    if G.db.last_export then
        G.bytes=math.max(0,G.bytes-G.storageSize(G.db.last_export,1)); G.db.last_export=nil
    end
end
function G.saveExport()
    if not G.db or #G.db.sessions==0 then return end
    G.dropExport()
    local s=G.db.sessions[#G.db.sessions]; local text=G.exportText(); local pages=G.pages(text)
    local block={record_schema=3,session_id=s.id,built_utc=GetServerTime(),pages=pages,total_pages=#pages,
        summary={kills=s.summary and s.summary.kills,clean_single=s.summary and s.summary.clean_single,elapsed=s.elapsed,xp_actual=s.summary and s.summary.xp_actual},complete=true}
    local base=G.bytes
    if base+G.storageSize(block,1)+1024>G.maxBytes then
        block.complete=false; block.note="Partial cached export: summary and first page only. Full session remains in sessions; use Export or collect saved file."
        block.pages={pages[1]}
        -- Reserve headroom normally fits the first page; under pressure shorten it explicitly.
        while base+G.storageSize(block,1)+1024>G.maxBytes and #block.pages[1]>0 do
            block.pages[1]=block.pages[1]:sub(1,math.floor(#block.pages[1]/2)); block.first_page_truncated=true
        end
    end
    G.db.last_export=block; G.bytes=G.bytes+G.storageSize(block,1)
end
local logout=CreateFrame("Frame")
logout:RegisterEvent("PLAYER_LOGOUT")
logout:SetScript("OnEvent",function()
    G.silent=true
    if G.session then G.stop("PLAYER_LOGOUT"); if G.session then G.finish() end end
    if G.db then G.saveExport() end
    G.silent=nil
end)
G.logoutFrame=logout
