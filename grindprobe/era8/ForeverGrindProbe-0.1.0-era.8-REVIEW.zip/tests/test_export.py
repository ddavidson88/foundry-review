import unittest
import test_grind

class ExportTests(unittest.TestCase):
 def make(self): return test_grind.Tests().make()
 def test_sizes_reassembly_selection_and_no_chat_dump(self):
  for size in (50000,257000,600000):
   l,g=self.make(); l.execute('finish(1)'); before=len(l.globals().messages)
   l.execute(f"G.exportText=function() return string.rep('x',{size}) end; G.export()")
   pages=[v for _,v in g.exportFrame.pages.items()]
   self.assertEqual(''.join(x.split('\n',1)[1] for x in pages),'x'*size)
   self.assertTrue(g.exportFrame.box.selected); self.assertTrue(g.exportFrame.box.focus)
   self.assertEqual(len(l.globals().messages),before)
   g.showPage(999); self.assertEqual(g.exportFrame.page,len(pages))
 def test_logout_active_silent_and_reload(self):
  l,g=self.make(); before=len(l.globals().messages)
  l.execute("hit(1); now=2; G.logoutFrame.scripts.OnEvent(); saved=G.json(G.db); G.db=nil; G.load()")
  self.assertEqual(len(l.globals().messages),before)
  self.assertEqual(g.db.last_export.record_schema,3)
  self.assertIsNotNone(g.db.last_export.pages[1]); self.assertIsNone(g.session)
 def test_stop_cache_and_repeat_no_growth(self):
  l,g=self.make(); l.execute('finish(1)'); self.assertIsNotNone(g.db.last_export)
  n=g.bytes; g.saveExport(); self.assertEqual(g.bytes,n)
 def test_cache_fallback_bounded(self):
  l,g=self.make(); l.execute("finish(1); G.exportText=function() return string.rep('x',600000) end; G.bytes=G.maxBytes-64000; G.saveExport()")
  self.assertFalse(g.db.last_export.complete); self.assertEqual(len(g.db.last_export.pages),1)
  self.assertIsNone(g.db.last_export.first_page_truncated)
  self.assertLess(g.bytes,g.maxBytes)
 def test_skill_storm_and_summary_bound(self):
  l,g=self.make(); l.execute("hit(1); for i=1,100 do skillrank=i; event('SKILL_LINES_CHANGED') end; died(3)")
  self.assertEqual(len(g.session.contexts),1)
  self.assertEqual(g.session.records[1].skills_engage.Swords.rank,10)
  self.assertEqual(g.session.records[1].skills_end.Swords.rank,100)
  l.execute("for i=1,20 do links[16]='item:'..i; event('PLAYER_EQUIPMENT_CHANGED',16) end; G.stop()")
  before=len(l.globals().messages); l.execute('step(now+4)')
  self.assertLessEqual(len(l.globals().messages)-before,6)
 def test_legacy_schema2_export(self):
  l,g=self.make(); l.execute('finish(1); G.db.sessions[1].record_schema=2; G.summary(G.db.sessions[1]); G.export()')
  self.assertTrue(g.exportFrame.shown)

if __name__=='__main__':unittest.main()
