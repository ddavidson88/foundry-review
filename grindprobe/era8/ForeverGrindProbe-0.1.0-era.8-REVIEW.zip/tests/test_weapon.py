"""EMULATED CLEU tuples in the Era layout specified by reviewer.
Constructed values, NOT a native combat-log replay. Native XP string is in test_grind.
"""
import json
import unittest
from pathlib import Path
import test_grind

HARNESS=r'''
function cleu(t,kind,src,dst,...)
 now=t
 local suffix={...}
 local v={t,kind,false,src,src==player and 'Test' or 'Boar',0x511,0,dst,dst==player and 'Test' or 'Boar',0xa48,0}
 for i=1,select('#',...) do v[11+i]=select(i,...) end
 payload=v
 function CombatLogGetCurrentEventInfo() return unpack(payload,1,30) end
 event('COMBAT_LOG_EVENT_UNFILTERED')
end
function startcombat(t) now=t; event('PLAYER_REGEN_DISABLED') end
function endcombat(t) now=t; event('PLAYER_REGEN_ENABLED') end
function swing(t,src,dst,amount,over,blocked,absorbed,crit,glance,crush)
 cleu(t,'SWING_DAMAGE',src,dst,amount,over or -1,1,0,blocked or 0,absorbed or 0,crit,glance,crush,false)
end
function miss(t,src,dst,kind,amount)
 cleu(t,'SWING_MISSED',src,dst,kind,false,amount)
end
function heal(t,src,amount,over)
 cleu(t,'SPELL_HEAL',src,player,2061,'Flash Heal',2,amount,over,0,false)
end
function kill(t)
 cleu(t,'UNIT_DIED',nil,mob)
 award(t,55); update(t,155); step(t+.3); step(t+3.2)
end
'''

class WeaponTests(unittest.TestCase):
    def make(self):
        l,g=test_grind.Tests().make(); l.execute(HARNESS); return l,g

    def test_single_damage_and_summary(self):
        l,g=self.make()
        l.execute('startcombat(1); swing(1,player,mob,20); health=90; swing(2,mob,player,10); swing(3,player,mob,80,5); kill(4); endcombat(8); health=100; now=12; event("UNIT_HEALTH","player"); finish(13)')
        s=g.db.sessions[1]; r=s.records[1]; q=s.summary.weapon_contexts[1]
        self.assertEqual((r.dmg_out,r.overkill_out,r.dmg_in),(95,5,10))
        self.assertEqual((r.hp_engage,r.hp_end),(100,90))
        self.assertEqual((r.episode,r.context_engage,r.context_end),(1,1,1))
        self.assertEqual((q.clean_kills,q.median_ttk,q.mean_dmg_out,q.mean_dmg_in,q.median_full_recovery),(1,3,95,10,4))
        self.assertEqual(s.episodes[1].hp_unexplained,0)

    def test_combat_end_before_death_grace_clean(self):
        l,g=self.make()
        l.execute('startcombat(1); swing(1,player,mob,20); health=80; rage=15; endcombat(4); health=100; rage=0; kill(4.1); finish(9)')
        s=g.db.sessions[1]; r=s.records[1]
        self.assertEqual((s.summary.kills,s.summary.clean_single,r.xp_total),(1,1,55))
        self.assertEqual((r.t_end,r.t_death,r.hp_end,r.rage_end),(4,4.1,80,15))
        self.assertEqual(r.close_reason,'mob_death'); self.assertIsNone(r.flags.incomplete)
        self.assertAlmostEqual(s.summary.weapon_contexts[1].median_ttk,3.1)

    def test_death_before_combat_end_clean(self):
        l,g=self.make()
        l.execute('startcombat(1); swing(1,player,mob,20); kill(4); endcombat(8); finish(9)')
        s=g.db.sessions[1]; r=s.records[1]
        self.assertEqual((s.summary.kills,s.summary.clean_single,r.xp_total),(1,1,55))
        self.assertEqual((r.t_end,r.t_death,r.close_reason),(4,4,'mob_death'))

    def test_evade_timeout_death_at_grace_boundary(self):
        l,g=self.make()
        l.execute('startcombat(1); swing(1,player,mob,20); health=70; rage=10; step(32); health=90; rage=0; kill(37)')
        r=g.session.records[1]
        self.assertEqual((r.t_end,r.t_death,r.hp_end,r.rage_end),(32,37,70,10))
        self.assertIsNone(r.flags.evade_or_flee); self.assertIsNone(r.flags.incomplete)
        # Still reserved after the earlier close+5; late XP must settle before seal.
        self.assertIsNotNone(g.budget[r])
        l.execute('finish(41)')
        self.assertEqual((g.db.sessions[1].summary.kills,g.db.sessions[1].summary.clean_single),(1,1))
        self.assertGreater(g.bytes,g.storageSize(g.db))

    def test_death_after_grace_stays_incomplete(self):
        for close in ('endcombat(4)', 'step(32)'):
            with self.subTest(close=close):
                l,g=self.make()
                l.execute('startcombat(1); swing(1,player,mob,20); '+close)
                t=g.session.records[1].t_end+5.01
                l.execute(f'kill({t}); finish({t+4})')
                s=g.db.sessions[1]; r=s.records[1]
                self.assertIsNone(r.t_death); self.assertIsNone(r.xp_total)
                self.assertTrue(r.flags.incomplete); self.assertEqual(s.summary.kills,0)

    def test_duplicate_death_and_stopped_close_not_reopened(self):
        l,g=self.make()
        l.execute("startcombat(1); swing(1,player,mob,20); endcombat(4); kill(4.1); cleu(7.5,'UNIT_DIED',nil,mob); finish(8)")
        self.assertEqual(g.db.sessions[1].records[1].t_death,4.1)
        l,g=self.make()
        l.execute("startcombat(1); swing(1,player,mob,20); now=2; G.stop(); cleu(2.1,'UNIT_DIED',nil,mob); step(6)")
        self.assertIsNone(g.db.sessions[1].records[1].t_death)
        self.assertTrue(g.db.sessions[1].records[1].flags.incomplete)

    def test_miss_first_and_mob_initiated_payload(self):
        l,g=self.make(); l.execute('startcombat(1); miss(1,mob,player,"DODGE"); swing(3,player,mob,15)')
        r=g.session.records[1]
        self.assertEqual((r.t_engage,r.t_first_player_action,r.outcomes_in.dodge),(1,3,1))
        self.assertEqual(r.hp_engage,100)

    def test_defense_damage_suffix(self):
        l,g=self.make(); l.execute('''startcombat(1)
 swing(1,mob,player,8,-1,4,2,true,false,true)
 miss(2,mob,player,'BLOCK',7); miss(3,mob,player,'ABSORB',11)
 miss(4,mob,player,'DODGE'); miss(5,mob,player,'PARRY'); miss(6,mob,player,'MISS')
 swing(7,player,mob,12,-1,3,0,true,true,false)
 miss(8,player,mob,'PARRY'); miss(9,player,mob,'DODGE'); miss(10,player,mob,'BLOCK',2)
 ''')
        r=g.session.records[1]
        self.assertEqual((r.dmg_in,r.blocked_in,r.absorbed_in),(8,11,13))
        for key in ('hit','crit','crushing','block_partial','block_full','dodge','parry','miss','absorb'):
            self.assertEqual(r.outcomes_in[key],1,key)
        self.assertEqual((r.outcomes_out.hit,r.outcomes_out.crit,r.outcomes_out.glancing,r.outcomes_out.block),(1,1,1,2))

    def test_spell_range_periodic_positions_and_caps(self):
        l,g=self.make(); l.execute('''startcombat(1)
 cleu(1,'SPELL_DAMAGE',player,mob,78,'Heroic Strike',1,30,5,1,0,0,0,true,false,false)
 cleu(2,'RANGE_DAMAGE',player,mob,75,'Auto Shot',1,12,-1,1,0,0,0,false,false,false)
 cleu(3,'SPELL_PERIODIC_DAMAGE',mob,player,100,'Dot',4,7,-1,4,0,2,3,false,false,false)
 cleu(4,'SPELL_MISSED',mob,player,101,'Bolt',4,'BLOCK',false,9)
 cleu(5,'RANGE_MISSED',player,mob,75,'Auto Shot',1,'MISS',false,nil)
 for i=1,20 do cleu(6+i,'SPELL_DAMAGE',player,mob,1000+i,'Spell',1,1,-1,1,0,0,0,false,false,false) end
 ''')
        r=g.session.records[1]
        self.assertEqual((r.dmg_out,r.dmg_in,r.blocked_in,r.absorbed_in),(57,7,11,3))
        self.assertEqual((r.spells[78].dmg,r.spells[75].n),(25,2))
        self.assertEqual(len(list(r.spells.items())),13)
        self.assertEqual(r.spells.other.n,10)

    def test_healing_and_bloodrage_residual(self):
        l,g=self.make(); l.execute('''startcombat(1); swing(1,mob,player,20)
 health=80; heal(2,player,15,5); health=85; endcombat(3)''')
        e=g.session.episodes[1]
        self.assertEqual((e.dmg_in,e.heal_in,e.overheal_in,e.hp_unexplained),(20,10,5,5))
        self.assertEqual(e.heals[2061].heal,10)

    def test_recovery_logged_heals_auras_and_full(self):
        l,g=self.make(); l.execute('''startcombat(1); health=70; endcombat(2)
 for i=1,15 do cleu(2.1,'SPELL_AURA_APPLIED',player,player,i,'Food '..i,1,'BUFF') end
 heal(3,player,10,2); health=78
 now=4; event('UNIT_HEALTH','target'); health=100; now=7; event('UNIT_HEALTH','player')''')
        r=g.session.recoveries[1]
        self.assertEqual((r.outcome,r.t_full,r.heal_in,r.overheal_in,r.hp_net_gain,r.unlogged_gain),('full',7,8,2,30,22))
        self.assertEqual(len(list(r.auras.items())),9)
        self.assertIsNone(r.auras.other.name)

    def test_heal_cap(self):
        l,g=self.make(); l.execute("startcombat(1); for i=1,20 do cleu(2,'SPELL_PERIODIC_HEAL',player,player,i,'Heal',2,5,1,0,false) end")
        e=g.session.episodes[1]
        self.assertEqual((e.heal_in,e.overheal_in),(80,20))
        self.assertEqual(len(list(e.heals.items())),7)
        self.assertEqual(e.heals.other.n,14)

    def test_gear_between_and_midfight(self):
        l,g=self.make(); l.execute('''links[16]='|Hitem:9603|h[Staff]|h'; event('PLAYER_EQUIPMENT_CHANGED',16)
 startcombat(1); swing(1,player,mob,10); links[17]='|Hitem:1|h[Shield]|h'; now=2; event('PLAYER_EQUIPMENT_CHANGED',17)
 kill(4); finish(8)''')
        s=g.db.sessions[1]; r=s.records[1]
        self.assertEqual((r.context_engage,r.context_end),(2,3))
        self.assertTrue(r.flags.gear_changed_midfight); self.assertTrue(r.flags.context_changed_midfight)
        self.assertEqual(s.summary.clean_single,0)
        self.assertEqual(s.contexts[2]['items'][16].link,'|Hitem:9603|h[Staff]|h')

    def test_skill_diff_informational(self):
        l,g=self.make(); l.execute('''event('SKILL_LINES_CHANGED'); startcombat(1); swing(1,player,mob,10)
 skillrank=11; now=2; event('SKILL_LINES_CHANGED'); event('SKILL_LINES_CHANGED'); kill(4); finish(8)''')
        s=g.db.sessions[1]; r=s.records[1]
        self.assertEqual(len(s.contexts),1); self.assertIsNone(r.flags.context_changed_midfight)
        self.assertIsNone(r.flags.gear_changed_midfight); self.assertEqual(s.summary.clean_single,1)
        self.assertEqual(r.skills_end.Swords.rank,11)
        self.assertIsNone(r.skills_end.Cooking)

    def test_level_and_missing_link(self):
        l,g=self.make(); l.execute("event('PLAYER_LEVEL_UP',3)")
        self.assertEqual(g.session.contexts[2].level,3)
        c=g.session.contexts[1]
        self.assertTrue(c['items'][17].missing); self.assertIsNone(c['items'][17].link)
        self.assertEqual((c.effectiveUnitArmor,c.attackPower,c.mhSpeed),(30,24,2))
        self.assertIsNone(c.ohSpeed)

    def test_two_mobs_per_guid_one_episode(self):
        l,g=self.make(); l.execute('startcombat(1); swing(1,mob,player,7); swing(2,mob2,player,13); health=80; endcombat(3)')
        s=g.session; e=s.episodes[1]
        self.assertEqual((len(s.episodes),len(e.guids),e.dmg_in),(1,2,20))
        self.assertTrue(e.multi)
        self.assertEqual((s.records[1].dmg_in,s.records[2].dmg_in),(7,13))

    def test_external_damage_and_heal(self):
        l,g=self.make(); l.execute("startcombat(1); swing(1,player,mob,10); swing(2,'Player-Other',mob,30); heal(3,'Player-Other',10,0)")
        r=g.session.records[1]
        self.assertEqual(r.dmg_out,10); self.assertTrue(r.flags.external_damage); self.assertTrue(r.flags.external_heal)
        self.assertTrue(g.episode.external_heal)

    def test_pause_recovery_no_reopen_on_resume(self):
        l,g=self.make(); l.execute("startcombat(1); health=50; endcombat(2); now=3; G.pause(); now=10; G.resume(); health=100; event('UNIT_HEALTH','player')")
        self.assertEqual(g.session.recoveries[1].outcome,'paused'); self.assertIsNone(g.recovery)
        l.execute('step(12)'); self.assertEqual(g.session.elapsed,5)

    def test_combat_interrupts_recovery(self):
        l,g=self.make(); l.execute('startcombat(1); health=50; endcombat(2); health=65; startcombat(5)')
        r=g.session.recoveries[1]
        self.assertEqual((r.outcome,r.hp_at_next_engage,r.unlogged_gain),('interrupted_by_combat',65,15))

    def test_death_closes_episode_and_recovery(self):
        l,g=self.make(); l.execute("startcombat(1); swing(1,mob,player,10); health=0; event('PLAYER_DEAD')")
        self.assertTrue(g.session.episodes[1].player_died)
        self.assertEqual(g.session.records[1].close_reason,'death')
        l2,g2=self.make(); l2.execute("startcombat(1); health=50; endcombat(2); health=0; event('PLAYER_DEAD')")
        self.assertEqual(g2.session.recoveries[1].outcome,'death')

    def test_evade_close(self):
        l,g=self.make(); l.execute("startcombat(1); miss(1,player,mob,'EVADE'); step(32)")
        r=g.session.records[1]
        self.assertTrue(r.flags.evade_or_flee); self.assertEqual(r.outcomes_out.evade,1)
        self.assertEqual(r.close_reason,'evade_timeout')

    def test_logout_and_world_transition_close_recovery(self):
        for event in ('PLAYER_LOGOUT','PLAYER_ENTERING_WORLD'):
            with self.subTest(event=event):
                l,g=self.make(); l.execute(f"startcombat(1); health=50; endcombat(2); now=3; event('{event}')")
                self.assertIsNone(g.session)
                self.assertEqual(g.db.sessions[1].recoveries[1].outcome,'stopped')

    def test_legacy_read_summary(self):
        l,g=self.make(); l.execute("finish(1); local s=G.db.sessions[1]; s.record_schema=nil; s.contexts=nil; s.episodes=nil; s.recoveries=nil; G.db=nil; G.load(); q=G.summary(ForeverGrindProbeDB.sessions[1])")
        self.assertEqual(g.db.schema,1); self.assertIsNone(g.db.sessions[1].record_schema)
        self.assertIsNone(l.globals().q.weapon_contexts)
        self.assertEqual(l.globals().q.kills,0)
        self.assertEqual(json.loads(g.exportText())['field_notes']['missing'],'absent = unavailable; items[].missing means no link, not item 0')

    def test_exact_era5_fixture_summary_unchanged(self):
        fixture=json.loads((Path(__file__).parent/'legacy-era5.json').read_text())
        l,g=test_grind.Tests().make(start=False)
        def convert(v):
            if not isinstance(v,dict): return v
            return l.table_from({int(k) if k.isdigit() else k:convert(x) for k,x in v.items()})
        l.globals().ForeverGrindProbeDB=convert(fixture)
        l.execute('G.load(); q=G.summary(G.db.sessions[1])')
        self.assertEqual(json.loads(g.json(l.globals().q)),fixture['sessions']['1']['summary'])
        self.assertIsNone(g.db.sessions[1].record_schema)
        l.execute("G.start('new')")
        self.assertEqual(g.session.record_schema,3); self.assertEqual(g.db.schema,1)

    def test_export_guard_never_truncates(self):
        l,g=self.make(); l.execute("finish(1); G.db.sessions[1].label=string.rep('x',200001); G.export()")
        self.assertTrue(g.exportFrame.shown)
        self.assertGreater(len(g.exportFrame.pages),1)
        self.assertEqual(len(json.loads(g.exportText())['session']['label']),200001)

    def test_context_cap_stress_conservative_and_stops(self):
        l,g=self.make(); l.execute('''for i=1,2000 do
          skillrank=i; now=i; event('PLAYER_EQUIPMENT_CHANGED',16); step(i)
          if G.closing or not G.session then break end
        end
        step(now+4)
        ''')
        self.assertIsNone(g.session)
        self.assertEqual(g.db.sessions[1].stop_reason,'storage_cap')
        self.assertGreater(g.bytes,g.storageSize(g.db))
        self.assertLess(g.storageSize(g.db),g.maxBytes)

    def test_running_budget_no_db_walk_and_cap(self):
        l,g=self.make(); l.execute('''local original=G.storageSize
 G.storageSize=function(v,d) assert(v~=G.db,'whole DB rescanned'); return original(v,d) end
 startcombat(1); swing(1,player,mob,10); kill(3); endcombat(7); finish(8)
 G.start('second'); G.maxBytes=G.bytes+65536+100; event('PLAYER_EQUIPMENT_CHANGED',16); step(20); step(24)
 ''')
        self.assertIsNone(g.session); self.assertEqual(g.db.sessions[2].stop_reason,'storage_cap')
        self.assertTrue(any('Storage cap reached' in v for _,v in l.globals().messages.items()))

    def test_seal_once_and_estimate_conservative(self):
        l,g=self.make(); l.execute('startcombat(1); swing(1,player,mob,10); kill(3); endcombat(7); step(9); finish(10)')
        before=g.bytes; g.seal(g.db.sessions[1].records[1]); self.assertEqual(before,g.bytes)
        self.assertGreater(g.bytes,g.storageSize(g.db))

    def test_start_in_combat_unavailable_episode(self):
        l,g=self.make(); l.execute("swing(1,player,mob,10)")
        self.assertTrue(g.session.records[1].flags.episode_unavailable)
        self.assertIsNone(g.session.records[1].episode)

    def test_full_at_combat_end_and_changed_recovery(self):
        l,g=self.make(); l.execute('startcombat(1); endcombat(2)')
        self.assertEqual(g.session.recoveries[1].t_full,2)
        self.assertIsNone(g.recovery)
        l.execute("startcombat(3); health=70; endcombat(4); event('PLAYER_EQUIPMENT_CHANGED',16); health=100; now=5; event('UNIT_HEALTH','player'); finish(6)")
        s=g.db.sessions[1]
        self.assertTrue(s.recoveries[2].context_changed)
        self.assertEqual(s.summary.weapon_contexts[1].full_recoveries,1)

if __name__=='__main__': unittest.main(verbosity=2)
