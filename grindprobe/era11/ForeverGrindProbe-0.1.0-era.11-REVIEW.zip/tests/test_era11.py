import unittest
import test_weapon
class DeathFinal(unittest.TestCase):
 def test_late_hit_dot_cast_do_not_reopen_dead_guid(self):
  l,g=test_weapon.WeaponTests().make()
  l.execute("startcombat(1); swing(1,player,mob,20); kill(2); old=G.json(G.session.records[1]); budget=G.bytes; swing(6,player,mob,5); cleu(6.1,'SPELL_PERIODIC_DAMAGE',player,mob,772,'Rend',1,3,-1,1,0,0,0,false,false,false); cleu(6.2,'SPELL_CAST_SUCCESS',player,mob,78,'Heroic Strike',1)")
  self.assertEqual(len(g.session.records),1)
  self.assertEqual(g.json(g.session.records[1]),l.globals().old)
  self.assertEqual(g.bytes,l.globals().budget)
  l.execute('step(40)'); self.assertEqual(len(g.session.records),1)
 def test_timeout_repull_keeps_damage_and_single_guid_episode(self):
  l,g=test_weapon.WeaponTests().make()
  l.execute('startcombat(1); swing(1,player,mob,10); step(32); old=G.json(G.session.records[1]); swing(33,player,mob,25)')
  self.assertEqual(len(g.session.records),2)
  self.assertEqual(g.session.records[2].dmg_out,25)
  self.assertEqual(g.json(g.session.records[1]),l.globals().old)
  self.assertFalse(g.session.episodes[1].multi)
  self.assertEqual(len(g.session.episodes[1].record_ids),2)
  self.assertEqual(len(g.session.episodes[1].guids),1)
