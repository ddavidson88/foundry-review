"""Mocked Lua 5.1 event tests. These do NOT prove WoW/Forever native behavior.

Run: python tests/test_probe.py (requires lupa with lua51 module).
Loads only the submitted addon Core/Capture Lua plus explicit test mocks.
"""
import json
from pathlib import Path
import unittest

from lupa.lua51 import LuaRuntime

ROOT = Path(__file__).resolve().parents[1]
MOCKS = r'''
State = {level=1,xp=0,max=400,clock=100,epoch=1000000,map=141,x=.123456789,y=.765432198,
  zone="Teldrassil",subzone="Shadowglen",guid="Player-1-0001",name="Probe",realm="Test Realm",skills={}}
Messages={}
DEFAULT_CHAT_FRAME={AddMessage=function(_,s) Messages[#Messages+1]=s end}
function GetTime() return State.clock end
function GetServerTime() return State.epoch end
function UnitLevel() return State.level end
function UnitXP() return State.xp end
function UnitXPMax() return State.max end
function GetXPExhaustion() return nil end
function GetRealmName() return State.realm end
function UnitGUID(unit) if unit=="player" then return State.guid else return "Creature-0-1-2-3-12345-000000" end end
function UnitName(unit) if unit=="player" then return State.name else return "Trainer" end end
function UnitClass() return "Warrior","WARRIOR" end
function UnitRace() return "Night Elf","NightElf" end
function GetBuildInfo() return "1.60.1","70450","Oct 22 2026",16001 end
function GetLocale() return "enUS" end
function GetZoneText() return State.zone end
function GetSubZoneText() return State.subzone end
function UnitPosition() if State.noWorld then return nil end; return 1234.567,9876.543,12.25,1 end
function UnitOnTaxi() return State.taxi or false end
function UnitExists(u) return u=="npc" end
function UnitIsUnit(a,b) return a==b end
function UnitCanAttack() return false end
function UnitIsDeadOrGhost() return false end
function GetNumSkillLines() return #State.skills end
function GetSkillLineInfo(i) local s=State.skills[i]; return s.name,false,false,s.rank,0,0,s.max end
C_QuestLog={GetTitleForQuestID=function(id) return "Quest "..tostring(id) end}
C_Map={
 GetBestMapForUnit=function() return State.map end,
 GetPlayerMapPosition=function()
  if State.noPosition then return nil end
  return {GetXY=function() return State.x,State.y end}
 end
}
ERR_ZONE_EXPLORED_XP="Discovered %s: %d experience gained"
ERR_ZONE_EXPLORED="Discovered %s"
ERR_SKILL_GAINED_S="You have gained the %s skill."
ERR_LEARN_SPELL_S="You have learned a new spell: %s."
function CreateFrame()
 return setmetatable({scripts={},events={},RegisterEvent=function(self,e) self.events[e]=true end,
  SetScript=function(self,k,v) self.scripts[k]=v end},
  {__index=function() return function() end end})
end
SlashCmdList={}
'''


class Harness:
    def __init__(self, autostart=True):
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        self.lua.execute(MOCKS)
        self.g = self.lua.globals()
        self.load_modules()
        if autostart:
            self.event("ADDON_LOADED", "ForeverRouteProbe")
            self.event("PLAYER_ENTERING_WORLD", True, False)

    def load_modules(self):
        self.p = self.lua.table()
        for filename in ("Core.lua", "Capture.lua"):
            self.lua.execute((ROOT / "ForeverRouteProbe" / filename).read_text(), "ForeverRouteProbe", self.p)

    def event(self, event, *args):
        self.p.onEvent(self.p.frame, event, *args)

    def update(self, dt=.1):
        self.g.State.clock += dt
        self.p.frame.scripts.OnUpdate(self.p.frame, dt)

    def set(self, **kw):
        for k, v in kw.items():
            self.g.State[k] = v

    def records(self, kind=None):
        events = self.p.session.events
        rows = [events[i] for i in range(1, len(events) + 1)]
        return rows if kind is None else [r for r in rows if r.kind == kind]

    def reload(self):
        self.load_modules()
        self.event("ADDON_LOADED", "ForeverRouteProbe")
        self.event("PLAYER_ENTERING_WORLD", False, True)

    def ui(self):
        self.lua.execute((ROOT / "ForeverRouteProbe" / "UI.lua").read_text(), "ForeverRouteProbe", self.p)


class ProbeTests(unittest.TestCase):
    def test_fresh_character_autoarms_only_once(self):
        h = Harness()
        self.assertTrue(h.p.session.active)
        self.assertEqual(len(h.p.db.sessions), 1)
        h.event("PLAYER_ENTERING_WORLD", False, False)
        self.assertEqual(len(h.p.db.sessions), 1)
        h.p.stop()
        h.reload()
        self.assertFalse(h.p.session.active)
        self.assertEqual(len(h.p.db.sessions), 1)

    def test_existing_character_needs_explicit_start(self):
        h = Harness(False)
        h.set(level=5, xp=800, max=2800)
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        h.event("PLAYER_ENTERING_WORLD", True, False)
        self.assertIsNone(h.p.session)
        h.p.start("manual")
        self.assertTrue(h.p.session.active)

    def test_w1_discovery_and_kill_remain_distinct(self):
        h = Harness()
        h.event("UI_INFO_MESSAGE", 0, "Discovered Dolanaar: 45 experience gained")
        h.event("CHAT_MSG_COMBAT_XP_GAIN", "Young Nightsaber dies, you gain 50 experience.")
        h.set(xp=95)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.records("discovery_xp")[0].data.amount, 45)
        self.assertEqual(h.records("discovery_xp")[0].data.area, "Dolanaar")
        self.assertEqual(len(h.records("kill_xp_message")), 1)
        self.assertEqual(h.records("xp_update")[-1].data.delta, 95)

    def test_xp_update_does_not_imply_exploration(self):
        h = Harness()
        h.set(xp=20)
        h.event("ZONE_CHANGED")
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.records("xp_update")[-1].data.delta, 20)
        self.assertEqual(h.records("discovery_xp"), [])

    def test_w2_level_announcement_before_xp_state(self):
        h = Harness()
        h.set(xp=390)
        h.event("PLAYER_XP_UPDATE", "player")
        h.event("PLAYER_LEVEL_UP", 2)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(level=2, xp=35, max=900)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.records("xp_update")[-1].data.delta, 45)
        self.assertEqual(h.p.session.baseline.level, 2)
        self.assertEqual(len(h.records("level_up")), 1)

    def test_w2_xp_before_level_notification(self):
        h = Harness()
        h.set(xp=390)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(xp=35)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.p.session.baseline.xp, 390)
        h.set(level=2, max=900)
        h.event("PLAYER_LEVEL_UP", 2)
        h.update()
        self.assertEqual(h.records("xp_update")[-1].data.delta, 45)

    def test_level_notification_does_not_advance_without_xp_event(self):
        h = Harness()
        h.set(xp=390)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(level=2, max=900)
        h.event("PLAYER_LEVEL_UP", 2)
        h.update()
        self.assertEqual(h.p.session.baseline.level, 1)
        h.set(xp=35)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.records("xp_update")[-1].data.delta, 45)

    def test_multi_level_gap_is_unresolved(self):
        h = Harness()
        h.set(level=3, xp=40, max=1400)
        h.event("PLAYER_XP_UPDATE", "player")
        data = h.records("xp_update")[-1].data
        self.assertIsNone(data.delta)
        self.assertEqual(data.status, "unresolved_level_order_or_gap")

    def test_w3_reload_same_baseline_no_gap(self):
        h = Harness()
        h.set(xp=30)
        h.event("PLAYER_XP_UPDATE", "player")
        sid = h.p.session.id
        before = len(h.records())
        h.reload()
        self.assertEqual(h.p.session.id, sid)
        self.assertGreater(len(h.records()), before)
        self.assertEqual(h.p.session.segment, 2)
        self.assertEqual(h.records("xp_unaccounted"), [])
        self.assertTrue(h.records("world_entry")[-1].data.reload)

    def test_w3_reload_changed_baseline_explicit_gap(self):
        h = Harness()
        h.set(xp=50)
        h.reload()
        gap = h.records("xp_unaccounted")[-1].data
        self.assertEqual(gap.previous.xp, 0)
        self.assertEqual(gap.current.xp, 50)
        h.set(xp=75)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.records("xp_update")[-1].data.delta, 25)

    def test_w4_missing_map_keeps_discovery(self):
        h = Harness()
        h.set(map=None)
        h.event("CHAT_MSG_SYSTEM", "Discovered Lake: 45 experience gained")
        r = h.records("discovery_xp")[-1]
        self.assertFalse(r.pos.valid)
        self.assertIsNone(r.pos.x)
        self.assertEqual(r.pos.reason, "map_unavailable")
        self.assertEqual(r.data.amount, 45)

    def test_w4_missing_position_keeps_quest(self):
        h = Harness()
        h.set(noPosition=True)
        h.event("QUEST_TURNED_IN", 123, 100, 20)
        r = h.records("quest_turned_in")[-1]
        self.assertFalse(r.pos.valid)
        self.assertEqual(r.data.xp, 100)
        self.assertEqual(r.data.money, 20)

    def test_w5_visit_is_not_learning(self):
        h = Harness()
        h.event("TRAINER_SHOW")
        self.assertEqual(len(h.records("trainer_opened")), 1)
        self.assertEqual(h.records("skill_learned"), [])
        self.assertEqual(h.records("trainer_opened")[0].data.npc.id, 12345)
        h.lua.execute('State.skills={{name="Cooking",rank=1,max=75}}')
        h.event("SKILL_LINES_CHANGED")
        h.event("CHAT_MSG_SYSTEM", "You have gained the Cooking skill.")
        self.assertEqual(h.records("skill_learned")[-1].data.learned, "Cooking")
        self.assertEqual(h.records("skills_changed")[-1].data.changes.Cooking.current.rank, 1)

    def test_localized_positional_format_and_punctuation(self):
        h = Harness(False)
        h.g.ERR_ZONE_EXPLORED_XP = "%2$d XP: [%1$s] (neu)! 100%%"
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        h.event("PLAYER_ENTERING_WORLD", True, False)
        h.event("CHAT_MSG_SYSTEM", "85 XP: [Rut'theran] (neu)! 100%")
        r = h.records("discovery_xp")[-1]
        self.assertEqual(r.data.amount, 85)
        self.assertEqual(r.data.area, "Rut'theran")

    def test_no_xp_discovery(self):
        h = Harness()
        h.event("CHAT_MSG_SYSTEM", "Discovered Aldrassil")
        self.assertEqual(h.records("discovery")[-1].data.area, "Aldrassil")
        self.assertIsNone(h.records("discovery")[-1].data.amount)

    def test_dual_channel_duplicate_retained_and_linked(self):
        h = Harness()
        msg = "Discovered Dolanaar: 45 experience gained"
        h.event("CHAT_MSG_SYSTEM", msg)
        h.event("UI_INFO_MESSAGE", 0, msg)
        rows = h.records("discovery_xp")
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1].data.duplicate_of, rows[0].seq)
        self.assertNotEqual(rows[1].data.channel, rows[0].data.channel)

    def test_duplicate_link_does_not_cross_session(self):
        h = Harness()
        msg = "Discovered Dolanaar: 45 experience gained"
        h.event("CHAT_MSG_SYSTEM", msg)
        h.p.stop()
        h.p.start("manual")
        h.event("CHAT_MSG_SYSTEM", msg)
        self.assertIsNone(h.records("discovery_xp")[0].data.duplicate_of)

    def test_record_cap_stops_without_deleting(self):
        h = Harness()
        h.p.maxRecords = 5
        for _ in range(10):
            h.event("ZONE_CHANGED")
        self.assertEqual(len(h.records()), 5)
        self.assertEqual(h.records()[-1].kind, "limit_reached")
        self.assertFalse(h.p.session.active)

    def test_byte_cap_stops_and_preserves_prior_events(self):
        h = Harness()
        before = len(h.records())
        first_kind = h.records()[0].kind
        h.p.maxBytes = h.p.session.bytes + 2048 + 10
        h.event("ZONE_CHANGED")
        self.assertEqual(len(h.records()), before + 1)
        self.assertEqual(h.records()[0].kind, first_kind)
        self.assertEqual(h.records()[-1].kind, "limit_reached")
        self.assertFalse(h.p.session.active)
        self.assertLess(h.p.session.bytes, h.p.maxBytes)

    def test_foreign_unit_xp_event_ignored(self):
        h = Harness()
        before = len(h.records())
        h.event("PLAYER_XP_UPDATE", "pet")
        self.assertEqual(len(h.records()), before)

    def test_serialization_preserves_false_and_control_characters(self):
        h = Harness()
        val = h.lua.table_from({"valid": False, "message": 'a"b\\c\n\t', "zero": 0})
        encoded = h.p.json(val)
        self.assertEqual(json.loads(encoded), {"valid": False, "message": 'a"b\\c\n\t', "zero": 0})

    def test_schema_unknown_preserved_and_disabled(self):
        h = Harness(False)
        h.lua.execute('ForeverRouteProbeDB={schema=99,keep="original"}')
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        self.assertIsNone(h.p.db)
        self.assertEqual(h.g.ForeverRouteProbeDB.keep, "original")

    def test_malformed_database_scalar_fails_closed(self):
        h = Harness(False)
        h.g.ForeverRouteProbeDB = 7
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        self.assertIsNone(h.p.db)
        self.assertEqual(h.g.ForeverRouteProbeDB, 7)

    def test_deferred_invalid_xp_does_not_flood(self):
        h = Harness()
        h.set(max=0)
        h.event("PLAYER_XP_UPDATE", "player")
        before = len(h.records("xp_update"))
        for _ in range(600):
            h.update(1 / 60)
        self.assertLessEqual(len(h.records("xp_update")) - before, 5)

    def test_raw_coordinate_precision_preserved(self):
        h = Harness()
        h.event("ZONE_CHANGED")
        self.assertEqual(h.records("zone_change")[-1].pos.x, .123456789)

    def test_missing_discovery_formats_reported(self):
        h = Harness(False)
        h.g.ERR_ZONE_EXPLORED_XP = None
        h.g.ERR_ZONE_EXPLORED = None
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        h.event("PLAYER_ENTERING_WORLD", True, False)
        self.assertEqual(h.p.session.capabilities.formats.ERR_ZONE_EXPLORED_XP, "missing")
        self.assertEqual(h.p.session.capabilities.formats.ERR_ZONE_EXPLORED, "missing")

    def test_level_and_max_before_xp_preserves_baseline(self):
        h = Harness()
        h.set(xp=390)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(level=2, max=900)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.p.session.baseline.level, 1)
        self.assertIsNone(h.records("xp_update")[-1].data.delta)
        h.event("PLAYER_LEVEL_UP", 2)
        h.set(xp=35)
        h.update()
        self.assertEqual(h.records("xp_update")[-1].data.delta, 45)
        self.assertEqual(h.p.session.baseline.xp, 35)
        self.assertIsNone(h.p.pendingXP)

    def test_mixed_max_does_not_replace_old_level_requirement(self):
        h = Harness()
        h.set(xp=390)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(max=900)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.p.session.baseline.max, 400)
        h.set(level=2, xp=35)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.records("xp_update")[-1].data.delta, 45)

    def test_contradicted_rollover_delta_explicitly_superseded(self):
        h = Harness()
        h.set(xp=390)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(level=2, max=900, xp=395)
        h.event("PLAYER_XP_UPDATE", "player")
        suspect = h.records("xp_update")[-1]
        self.assertTrue(suspect.data.provisional)
        h.set(xp=35)
        h.event("PLAYER_XP_UPDATE", "player")
        corrected = h.records("xp_update")[-1]
        self.assertEqual(corrected.data.status, "inconsistent_xp_reset")
        self.assertEqual(corrected.data.supersedes_seq, suspect.seq)
        self.assertIsNone(corrected.data.delta)
        self.assertEqual(h.p.session.baseline.xp, 35)
        self.assertIsNone(h.p.pendingXP)
        self.assertEqual(suspect.data.delta, 405)  # Raw prior observation is preserved.

    def test_unexplained_xp_decrease_recovers_as_unknown(self):
        h = Harness()
        h.set(xp=100)
        h.event("PLAYER_XP_UPDATE", "player")
        h.set(xp=20)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.p.session.baseline.xp, 100)
        h.update(1.1)
        last = h.records("xp_update")[-1].data
        self.assertEqual(last.status, "inconsistent_xp_reset")
        self.assertIsNone(last.delta)
        self.assertIsNone(last.supersedes_seq)
        self.assertEqual(h.p.session.baseline.xp, 20)
        self.assertIsNone(h.p.pendingXP)

    def test_quest_accept_supports_both_event_shapes(self):
        h = Harness()
        h.event("QUEST_ACCEPTED", 123)
        h.event("QUEST_ACCEPTED", 4, 456)
        one, two = h.records("quest_accepted")
        self.assertEqual(one.data.id, 123)
        self.assertIsNone(one.data.index)
        self.assertEqual(one.data.argument_count, 1)
        self.assertEqual(one.data.title, "Quest 123")
        self.assertEqual(two.data.id, 456)
        self.assertEqual(two.data.index, 4)
        self.assertEqual(two.data.arg1, 4)
        self.assertEqual(two.data.arg2, 456)
        self.assertEqual(two.data.argument_count, 2)

    def test_friendly_target_fallback_is_unconfirmed(self):
        h = Harness()
        h.lua.execute('function UnitExists(u) return u == "target" end; '
                      'function UnitGUID(u) return "Player-1-999" end; '
                      'function UnitName(u) return "Unrelated player" end')
        h.event("QUEST_TURNED_IN", 123, 100, 20)
        npc = h.records("quest_turned_in")[-1].data.npc
        self.assertEqual(npc.confidence, "unconfirmed_target")
        self.assertEqual(npc.unit, "target")
        self.assertIsNone(npc.id)

    def test_nested_corruption_fails_closed_and_preserves_data(self):
        corruptions = [
            'ForeverRouteProbeDB.sessions[1] = true',
            'ForeverRouteProbeDB.sessions[1].events = false',
            'ForeverRouteProbeDB.sessions[1].bytes = nil',
            'ForeverRouteProbeDB.sessions[1].segment = "bad"',
            'ForeverRouteProbeDB.sessions[1].baseline = {level="bad"}',
            'ForeverRouteProbeDB.current["Probe-TestRealm"] = 999',
            'ForeverRouteProbeDB.sessions[1].events[1] = true',
        ]
        for mutation in corruptions:
            with self.subTest(mutation=mutation):
                h = Harness()
                h.lua.execute(mutation)
                before = h.p.json(h.g.ForeverRouteProbeDB)
                h.reload()
                self.assertIsNone(h.p.db)
                self.assertIsNone(h.p.session)
                self.assertEqual(h.p.json(h.g.ForeverRouteProbeDB), before)

    def test_false_database_is_preserved(self):
        h = Harness(False)
        h.g.ForeverRouteProbeDB = False
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        self.assertIsNone(h.p.db)
        self.assertFalse(h.g.ForeverRouteProbeDB)

    def test_unavailable_initial_xp_baseline_recovers(self):
        h = Harness(False)
        h.set(level=None, xp=None, max=None)
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        h.p.start("manual")
        h.set(level=1, xp=20, max=400)
        h.event("PLAYER_XP_UPDATE", "player")
        self.assertEqual(h.p.session.baseline.xp, 20)
        self.assertIsNone(h.records("xp_update")[-1].data.delta)
        self.assertEqual(h.records("xp_update")[-1].data.status, "unavailable")

    def test_classic_era_metadata_survives_missing_optional_apis(self):
        h = Harness(False)
        h.lua.execute('WOW_PROJECT_ID=2; WOW_PROJECT_CLASSIC=2; WOW_PROJECT_MAINLINE=1; '
                      'function GetBuildInfo() return "1.15.9","99999","test",11509 end; '
                      'C_Map=nil; UnitPosition=nil; C_QuestLog=nil; GetNumSkillLines=nil; '
                      'GetProfessions=nil; GetProfessionInfo=nil; C_AddOns=nil')
        h.event("ADDON_LOADED", "ForeverRouteProbe")
        h.event("PLAYER_ENTERING_WORLD", True, False)
        h.event("QUEST_ACCEPTED", 4, 123)
        h.event("SKILL_LINES_CHANGED")
        self.assertEqual(h.p.session.build.projectID, 2)
        self.assertEqual(h.p.session.build.flavor, "Classic Era")
        self.assertEqual(h.p.session.build.interface, 11509)
        self.assertFalse(h.records("quest_accepted")[-1].pos.valid)
        self.assertEqual(h.records("skills_changed")[-1].data.method, "unavailable")
        self.assertTrue(h.p.session.active)

    def test_client_build_or_flavor_change_splits_active_session(self):
        changes = [
            'WOW_PROJECT_ID=2',
            'function GetBuildInfo() return "1.60.1","70451","test",16001 end',
            'WOW_PROJECT_ID=2; WOW_PROJECT_CLASSIC=2; '
            'function GetBuildInfo() return "1.15.9","99999","test",11509 end',
        ]
        for change in changes:
            with self.subTest(change=change):
                h = Harness()
                old = h.p.session
                old_count = len(old.events)
                h.lua.execute(change)
                h.reload()
                self.assertEqual(len(h.p.db.sessions), 2)
                self.assertNotEqual(h.p.session.id, old.id)
                self.assertFalse(old.active)
                self.assertEqual(old.closedReason, "client_changed")
                self.assertEqual(len(old.events), old_count)
                self.assertEqual(h.p.session.segment, 1)
                self.assertEqual(h.records("client_transition")[-1].data.previousSession, old.id)
                self.assertEqual(h.records("world_entry")[-1].data.client.build, h.p.session.build.build)

    def test_stopped_session_does_not_auto_restart_on_client_change(self):
        h = Harness()
        h.p.stop()
        sid = h.p.session.id
        h.lua.execute('WOW_PROJECT_ID=2')
        h.reload()
        self.assertEqual(h.p.session.id, sid)
        self.assertFalse(h.p.session.active)
        self.assertEqual(len(h.p.db.sessions), 1)

    def test_export_roundtrip_metadata_and_breadcrumb_mode(self):
        h = Harness()
        h.ui()
        h.event("CHAT_MSG_SYSTEM", "Discovered Dolanaar: 45 experience gained")
        h.update(2)
        h.p.stop()
        normal = [json.loads(line) for line in h.p.exportText(False).splitlines()]
        full = [json.loads(line) for line in h.p.exportText(True).splitlines()]
        self.assertFalse(normal[0]["header"]["active"])
        self.assertFalse(normal[0]["header"]["breadcrumbs_included"])
        self.assertTrue(full[0]["header"]["breadcrumbs_included"])
        self.assertEqual(normal[-1]["footer"]["exported"], len(normal) - 2)
        self.assertEqual(full[-1]["footer"]["exported"], len(h.records()))
        self.assertFalse(any(r.get("kind") == "breadcrumb" for r in normal))
        self.assertTrue(any(r.get("kind") == "breadcrumb" for r in full))


if __name__ == "__main__":
    unittest.main(verbosity=2)
