# Forever Route Probe 0.1.0-beta.1

**Review candidate — not independently cleared or tested in WoW.** GPT is author; Claude Launch Prep is requested reviewer. Do not install this candidate until the independent review and applicable installer/native checks are resolved.

Purpose: record the fresh Night Elf Warrior exploration fallback run, including discovery reward messages, positions, XP observations, quests, trainer visits, skills and travel. Raw evidence first; route/XP analysis happens afterward.

## Once cleared

A brand-new level-one character at 0 XP starts recording automatically. GetBuildInfo and WOW_PROJECT_ID are recorded; a changed client/build starts a separate session rather than combining clients. Other characters: `/probe start`. A small draggable status/export button says whether recording is active. `/probe stop` stops without deleting data; `/probe start` after a stop starts another session. `/probe mark dock` inserts a manual note at your position. `/probe hide` and `show` affect only the status button.

`/probe export` opens one copyable block containing session metadata, capability diagnostics and all non-breadcrumb records. Ctrl+A, Ctrl+C, paste the whole block into GPT Launch Prep. `/probe export full` includes movement points. The final footer proves the pasted block has an end; the reviewer/analyzer checks the counts. Very long copy blocks need native validation; full saved data remains available if the client or chat truncates the paste. Export currently selects this character's latest session; older sessions remain in the saved file.

`/probe save` requests `/reload` from a user command, out of combat. Use only at a convenient safe point; no automatic reloads. Recording does not need reloads to function. **WoW writes SavedVariables on normal reload/logout; a crash can lose the unsaved portion.** The checkpoint request event itself is not proof the client finished writing. Capture resumes across a normal reload/relog and records a marker. Any mismatch against the saved XP baseline is flagged.

Saved file: `<actual client root>\WTF\Account\<account>\SavedVariables\ForeverRouteProbe.lua`. Both PCs have a recorded beta root `C:\Program Files (x86)\World of Warcraft_classic_beta_`; installer validates `WowB.exe` and `Interface\AddOns`. Live `_forever_` was suggested in the review, but no exact live root is established by current machine-path evidence; never guess it. Use the verified live client root when it exists. Existing WTF/.bak data is untouched.

## Installer and delivery

`RUN-ME.cmd` starts through PowerShell 7 (`pwsh`) and invokes the installer in Windows PowerShell 5.1. Without an actual clearance/ZIP pair it runs a **read-only game preflight** with a local transcript/report. After independent clearance, RUN-ME automatically recognizes the exact clearance filename and exact reviewed ZIP beside the extracted files or one folder above, then uses the reviewed fresh-install path. Ambiguous pairs stop clearly. No clearance is included in this review candidate. It does not install this uncleared candidate. The installer detects existing beta, Classic Era and Forever candidates beneath the known or default WoW parent locations, verifies the executable and AddOns directory, and asks which to use when there is more than one. An explicit validated root is also supported; discovery of a folder is not proof of the client flavor. The fresh-install path in Installer.ps1 requires actual independent clearance JSON plus the exact reviewed ZIP, verifies the payload, and refuses existing addon folders. No clearance is supplied or fabricated. Post-review Foundry managed distribution remains preferred where supported. Windows parsing/execution is still pending; a Linux source check does not clear this installer. No admin/security-policy bypass is included.

## Controlled test after clearance (about 10–15 minutes plus travel)

Prerequisite: exact package cleared for testing; addon loaded with current build shown in export. Use a fresh NE Warrior if practical, or an existing low-level character and `/probe start`. Record which realm/client was used. Official Classic Era is an owner-approved smoke-test option after the beta closes; label those results **native Classic Era**, never Forever evidence. Forever requires its own load and event checks when playable; character creation alone cannot prove addon loading.

1. **S1 discovery:** enter one undiscovered area. Note the visible discovery/XP message. Export must contain discovery_xp with that area/reward, original map/coordinates, and source channel. If both channels fire, a duplicate record must reference the first; only one distinct award. If no new discovery record appears, stop the long-run plan and send the export.
2. **S2 kill:** kill one XP-awarding mob. Expect a separate kill_xp_message and XP observations. It must not become exploration.
3. **S3 quest:** turn in one quest. Expect quest ID, offered XP/copper, and location. Quest accept is captured if accepted during recording.
4. **S4 trainer:** open a trainer without buying: trainer_opened only, no claimed learned skill. Then learn an available skill/profession: look for skill/spell message or skills_changed evidence. Trainer availability and travel time vary; do not assume Fishing/Cooking can both be trained in Shadowglen.
5. **S5 reload:** `/probe save`; after loading, expect same session, incremented segment, world_entry, and no invented XP. If XP truly changed during the unsaved/unobserved period it must be xp_unaccounted.
6. **S6 export:** `/probe export`, copy/paste the whole block into GPT Launch Prep. A level-up during S1–S3 also checks rollover; otherwise test that on the next convenient level. Do not spend a whole run until S1 works.

These are pending client checks, not completed tests. The author package contains mocked Lua 5.1 evidence only. A single observed position is a practical crossing point, not a mathematically exact area boundary. No navigation/guide execution, gameplay automation, profession purchase or quest acceptance is performed.

Limits: at most 20,000 events / approximately 2.5 MB encoded event text per session, at most 10 sessions; stop-with-warning rather than silently erase. Two-second movement sampling while active; events capture immediately. A missing map position preserves the event with a reason. Discovery parsing depends on exposed localized globals and actual client channels, explicitly reported in capabilities. No beta/live game-mechanics assumptions are introduced by listing interfaces 16001 and 11509. These numbers are supported by pinned addon source, not by a native test on Dustin's client.
