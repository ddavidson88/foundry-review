[CmdletBinding()]
param(
    [switch]$Install,
    [switch]$Auto,
    [string]$ClientRoot,
    [string]$ClientExecutable,
    [string]$ClearancePath,
    [string]$ReviewedZipPath
)

& {
    Clear-Host
    function Show-Head($t) { Write-Host "`n== $t ==" -ForegroundColor Cyan }
    function Show-Info($t) { Write-Host "   $t" }
    function Show-Ok($t) { Write-Host "   [OK]   $t" -ForegroundColor Green }
    function Show-Warn($t) { Write-Host "   [WARN] $t" -ForegroundColor Yellow }
    function Show-Fail($t) { Write-Host "   [FAIL] $t" -ForegroundColor Red }
    function Show-Copy([string[]]$lines) {
        ($lines -join "`r`n") | Set-Clipboard
        Write-Host ' COPIED TO YOUR CLIPBOARD - paste to GPT Launch Prep ' -ForegroundColor Black -BackgroundColor White -NoNewline
        Write-Host ''
        $lines | ForEach-Object { Write-Host "  | $_" -ForegroundColor DarkYellow }
    }
    function Show-Next([string[]]$steps) {
        Write-Host "`n==================== NEXT STEPS ====================" -ForegroundColor Magenta
        $i = 1
        foreach ($s in $steps) { Write-Host "  $i. $s" -ForegroundColor Magenta; $i++ }
        Write-Host '====================================================' -ForegroundColor Magenta
    }
    function Assert-PlainPath([string]$path) {
        $node = Get-Item -LiteralPath $path -Force -ErrorAction Stop
        while ($null -ne $node) {
            if ($node.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "Linked/reparse path is not supported by this fresh installer: $($node.FullName)"
            }
            if ($node -is [IO.FileInfo]) { $node = $node.Directory } else { $node = $node.Parent }
        }
    }
    function Get-PlainFiles([string]$path) {
        foreach ($entry in Get-ChildItem -LiteralPath $path -Force -ErrorAction Stop) {
            if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked payload entry: $($entry.FullName)" }
            if ($entry.PSIsContainer) { Get-PlainFiles $entry.FullName } else { $entry }
        }
    }
    function Normalize-Relative([string]$path) {
        $p = $path.Replace('\', '/')
        if ([string]::IsNullOrWhiteSpace($p) -or $p -match '(^/|:|[\x00-\x1f])' -or
            @($p.Split('/') | Where-Object { $_ -eq '' -or $_ -eq '.' -or $_ -eq '..' -or $_ -match '[. ]$|[<>"|?*]' }).Count -gt 0) {
            throw "Invalid relative payload path: $path"
        }
        return $p
    }
    function Hash-Stream($stream) {
        $sha = [Security.Cryptography.SHA256]::Create()
        try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
        finally { $sha.Dispose() }
    }

    function Get-RelativeFile([string]$root, [string]$path) {
        # .NET Framework / Windows PowerShell 5.1 has no Path.GetRelativePath.
        $prefix = [IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
        $full = [IO.Path]::GetFullPath($path)
        if (-not $full.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Payload file is outside its root: $full"
        }
        return Normalize-Relative ($full.Substring($prefix.Length))
    }
    function Get-ClientCandidate([string]$root, [string]$exe) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { return }
        if (-not (Test-Path -LiteralPath (Join-Path $root 'Interface\AddOns') -PathType Container)) { return }
        $found = @()
        if ($exe) { $found = @($exe) } else { $found = @('WowB.exe', 'WowClassic.exe', 'Wow.exe') }
        foreach ($name in $found) {
            $ep = Join-Path $root $name
            if (Test-Path -LiteralPath $ep -PathType Leaf) {
                [pscustomobject]@{ Root=(Get-Item -LiteralPath $root).FullName; Exe=$name }
            }
        }
    }

    $ErrorActionPreference = 'Stop' 
    $transcribing = $false
    $success = $false
    $stage = $null
    $archive = $null
    $report = [Collections.Generic.List[string]]::new()
    $steps = @('Paste the copied result into GPT Launch Prep.')
    try {
        if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) { throw 'This delivery script runs in Windows PowerShell 5.1. Launch through RUN-ME.cmd from your normal environment.' }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $outRoot = switch ($env:COMPUTERNAME.ToUpperInvariant()) {
            'DUSTYHOMEPC' { 'C:\Users\dd\Documents\Video Games\WoW\Forever\ForeverAI\Outputs\Scripts' }
            'WORKLAPTOP' { 'C:\Users\ddavi\Apps\ForeverAI Outputs\Scripts' }
            default { throw "Unknown PC $env:COMPUTERNAME; no output or installation path was guessed." }
        }
        [IO.Directory]::CreateDirectory($outRoot) | Out-Null
        $log = Join-Path $outRoot ('RouteProbe-' + (Get-Date -Format 'yyyyMMddTHHmmssfff') + '.log')
        Start-Transcript -LiteralPath $log | Out-Null
        $transcribing = $true
        if ($Auto) {
            if ($Install -or $ClearancePath -or $ReviewedZipPath) {
                throw '-Auto cannot be combined with explicit install/clearance arguments.'
            }
            # Only the two exact review artifacts beside this source or one parent up.
            # No stamp is generated here; the independent reviewer must supply it.
            $clearName = 'ForeverAI-Clearance-ForeverRouteProbe-0.1.0-beta.1.json'
            $zipName = 'ForeverRouteProbe-0.1.0-beta.1-REVIEW.zip'
            $clearMatches = @()
            $zipMatches = @()
            $locations = @($PSScriptRoot, (Split-Path -Parent $PSScriptRoot)) | Sort-Object -Unique
            foreach ($location in $locations) {
                if (-not $location) { continue }
                $clearFile = Join-Path $location $clearName
                $zipFile = Join-Path $location $zipName
                if (Test-Path -LiteralPath $clearFile) {
                    if (-not (Test-Path -LiteralPath $clearFile -PathType Leaf)) { throw "Clearance path is not a file: $clearFile" }
                    Assert-PlainPath $clearFile
                    $clearMatches += $clearFile
                }
                if (Test-Path -LiteralPath $zipFile) {
                    if (-not (Test-Path -LiteralPath $zipFile -PathType Leaf)) { throw "Reviewed ZIP path is not a file: $zipFile" }
                    Assert-PlainPath $zipFile
                    $zipMatches += $zipFile
                }
            }
            if ($clearMatches.Count -gt 1 -or $zipMatches.Count -gt 1) {
                throw 'Ambiguous clearance/reviewed-ZIP files beside the source or its parent. Nothing was installed; retain the files and request an exact pair.'
            }
            if ($clearMatches.Count -eq 1 -and $zipMatches.Count -eq 1) {
                $ClearancePath = $clearMatches[0]
                $ReviewedZipPath = $zipMatches[0]
                $Install = $true
            } else {
                Show-Info 'No complete independent clearance/ZIP pair found. Running read-only preflight.'
            }
        }
        Show-Head 'ForeverRouteProbe fresh-install preflight'
        Show-Info $(if ($Install) { 'Changes: create only the new ForeverRouteProbe addon folder after clearance and hash checks. No existing addon or saved data is changed.' } else { 'Read-only game check. Only a transcript/report is written to the approved Outputs folder; no addon files are changed.' })
        $report.Add("PC=$env:COMPUTERNAME; mode=$(if ($Install) { 'install' } else { 'preflight' })")
        if ($ClientExecutable -and ([IO.Path]::GetFileName($ClientExecutable) -ine $ClientExecutable -or
            $ClientExecutable -notin @('WowB.exe','WowClassic.exe','Wow.exe'))) {
            throw 'ClientExecutable must name WowB.exe, WowClassic.exe or Wow.exe, never a path.'
        }
        $candidates = @()
        if ($ClientRoot) {
            $candidates = @(Get-ClientCandidate $ClientRoot $ClientExecutable)
        } else {
            # Bounded candidates only. These are discovery locations, not asserted install targets.
            $roots = @('C:\Program Files (x86)\World of Warcraft_classic_beta_')
            foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
                if ($base) {
                    foreach ($flavor in @('_classic_era_','_classic_beta_','_forever_')) {
                        $roots += Join-Path (Join-Path $base 'World of Warcraft') $flavor
                    }
                }
            }
            foreach ($root in @($roots | Sort-Object -Unique)) {
                $candidates += @(Get-ClientCandidate $root $ClientExecutable)
            }
        }
        if ($candidates.Count -eq 0) {
            throw 'No validated client found. No game path was guessed. Supply -ClientRoot with the actual client folder; it must contain an executable and Interface\AddOns.'
        }
        for ($i=0; $i -lt $candidates.Count; $i++) {
            Show-Info ("{0}. {1} [{2}]" -f ($i+1), $candidates[$i].Root, $candidates[$i].Exe)
        }
        $selected = 0
        if ($candidates.Count -gt 1) {
            $choice = Read-Host 'Select the client number for this run (no default)'
            $number = 0
            if (-not [int]::TryParse($choice, [ref]$number) -or $number -lt 1 -or $number -gt $candidates.Count) {
                throw 'No valid client selected. No addon files changed.'
            }
            $selected = $number-1
        }
        $client = $candidates[$selected].Root
        $ClientExecutable = $candidates[$selected].Exe
        Assert-PlainPath $client
        $exePath = Join-Path $client $ClientExecutable
        Assert-PlainPath $exePath
        $exeInfo = (Get-Item -LiteralPath $exePath).VersionInfo
        $report.Add("ClientRoot=$client; executable=$ClientExecutable; file_version=$($exeInfo.FileVersion); product_version=$($exeInfo.ProductVersion); flavor_from_folder_is_hint_only=true")
        $addons = Join-Path $client 'Interface\AddOns'
        if (-not (Test-Path -LiteralPath $addons -PathType Container)) { throw "AddOns root not found: $addons" }
        Assert-PlainPath $addons
        $destination = Join-Path $addons 'ForeverRouteProbe'
        $existing = @(Get-ChildItem -LiteralPath $addons -Force | Where-Object { $_.Name -ieq 'ForeverRouteProbe' })
        if ($existing.Count -gt 0) { throw "An entry named ForeverRouteProbe already exists. This installer performs fresh installs only; nothing was overwritten." }
        $source = Join-Path $PSScriptRoot 'ForeverRouteProbe'
        Assert-PlainPath $source
        $manifestPath = Join-Path $PSScriptRoot 'PAYLOAD-SHA256.json'
        $manifest = @(Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json)
        if ($manifest.Count -lt 1) { throw 'The payload manifest is empty.' }
        $wanted = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
        foreach ($item in $manifest) {
            $rel = Normalize-Relative ([string]$item.path)
            if ([string]$item.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw "Invalid hash: $rel" }
            if ($wanted.ContainsKey($rel)) { throw "Duplicate/case-colliding manifest path: $rel" }
            $wanted.Add($rel, ([string]$item.sha256).ToLowerInvariant())
        }
        $files = @(Get-PlainFiles $source)
        if ($files.Count -ne $wanted.Count) { throw 'Payload inventory differs from the manifest.' }
        foreach ($file in $files) {
            $rel = Get-RelativeFile $source $file.FullName
            if (-not $wanted.ContainsKey($rel) -or (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash -ine $wanted[$rel]) {
                throw "Payload integrity mismatch: $rel"
            }
        }
        if (-not $wanted.ContainsKey('ForeverRouteProbe.toc')) { throw 'The addon TOC is missing.' }
        Show-Ok "Verified $($files.Count) payload files. Target: $destination"
        $report.Add("Target=$destination; payload_files=$($files.Count)")

        if ($Install) {
            if (-not $ClearancePath -or -not $ReviewedZipPath) { throw 'Install requires -ClearancePath and -ReviewedZipPath from the independent reviewer. This candidate does not include clearance.' }
            $clearance = Get-Content -LiteralPath $ClearancePath -Raw | ConvertFrom-Json
            if ($clearance.format -cne 'FOREVERAI_CLEARANCE_V1' -or $clearance.verdict -cne 'CLEARED' -or
                $clearance.addon_folder -ine 'ForeverRouteProbe' -or $clearance.addon_id -ine 'ForeverRouteProbe' -or
                [string]::IsNullOrWhiteSpace($clearance.author) -or [string]::IsNullOrWhiteSpace($clearance.reviewer) -or
                $clearance.author -ieq $clearance.reviewer) { throw 'Missing or invalid independent addon clearance.' }
            if ([IO.Path]::GetFileName($ReviewedZipPath) -ine $clearance.reviewed_zip_name -or
                [string]$clearance.reviewed_zip_sha256 -notmatch '^[a-fA-F0-9]{64}$' -or
                (Get-FileHash -LiteralPath $ReviewedZipPath -Algorithm SHA256).Hash -ine $clearance.reviewed_zip_sha256) { throw 'Reviewed ZIP filename/hash does not match the clearance.' }
            $toc = Get-Content -LiteralPath (Join-Path $source 'ForeverRouteProbe.toc') -Raw
            $version = [regex]::Match($toc, '(?m)^## Version:\s*(\S+)').Groups[1].Value
            if (-not $version -or $version -cne $clearance.version) { throw 'TOC version does not match the clearance.' }
            $interfaceText = [regex]::Match($toc, '(?m)^## Interface:\s*([^\r\n]+)').Groups[1].Value
            $interfaces = @($interfaceText.Split(',') | ForEach-Object { $_.Trim() })
            $clearedInterfaces = @($clearance.interfaces | ForEach-Object { [string]$_ })
            if (-not $interfaceText -or $clearedInterfaces.Count -eq 0) { throw 'Missing TOC or clearance interface declarations.' }
            foreach ($interface in $interfaces) {
                if ($interface -notmatch '^\d+$' -or $interface -notin $clearedInterfaces) {
                    throw "TOC interface $interface is not covered by this clearance."
                }
            }

            $zipRoot = 'ForeverRouteProbe'
            if ($clearance.addon_root) { $zipRoot = Normalize-Relative ([string]$clearance.addon_root) }
            $archive = [IO.Compression.ZipFile]::OpenRead((Resolve-Path -LiteralPath $ReviewedZipPath).Path)
            $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
            foreach ($entry in $archive.Entries) {
                if ($entry.FullName.EndsWith('/')) { continue }
                if (-not $entry.FullName.StartsWith($zipRoot + '/', [StringComparison]::OrdinalIgnoreCase)) { continue }
                $rel = Normalize-Relative ($entry.FullName.Substring($zipRoot.Length + 1))
                if (-not $seen.Add($rel) -or -not $wanted.ContainsKey($rel)) { throw "Reviewed ZIP payload inventory mismatch: $rel" }
                $stream = $entry.Open()
                try { $hash = Hash-Stream $stream } finally { $stream.Dispose() }
                if ($hash -cne $wanted[$rel]) { throw "Extracted payload differs from reviewed ZIP: $rel" }
            }
            if ($seen.Count -ne $wanted.Count) { throw 'Reviewed ZIP does not contain the complete payload.' }
            $archive.Dispose(); $archive = $null
            $stage = Join-Path $addons ('.ForeverRouteProbe-stage-' + [guid]::NewGuid().ToString('N'))
            [IO.Directory]::CreateDirectory($stage) | Out-Null
            foreach ($file in $files) {
                $rel = Get-RelativeFile $source $file.FullName
                $target = Join-Path $stage $rel.Replace('/', '\')
                [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
                Copy-Item -LiteralPath $file.FullName -Destination $target -ErrorAction Stop
                if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ine $wanted[$rel.Replace('\','/')]) { throw "Staged hash mismatch: $rel" }
            }
            # Same-parent directory rename: complete payload is exposed together; existing destination fails closed.
            [IO.Directory]::Move($stage, $destination)
            $stage = $null
            Show-Ok 'Installed on disk. Loading in the client has not been verified.'
            $report.Add('result=installed_on_disk; native_activation=unverified')
            $steps = @('Paste this report into GPT Launch Prep.', 'After review-approved test instructions, try /reload; restart the client only if this new addon is not recognized.')
        } else {
            Show-Ok 'Preflight completed. No addon files changed.'
            $report.Add('result=preflight_pass; installation=not_attempted')
            $steps = @('Paste this report into GPT Launch Prep. Installation remains pending actual independent clearance.')
        }
        $success = $true
    } catch {
        Show-Fail $_.Exception.Message
        $report.Add('result=failed; error=' + $_.Exception.Message)
        if ($stage) { $report.Add("Incomplete owned staging folder retained for diagnosis: $stage") }
    } finally {
        if ($archive) { $archive.Dispose() }
        if ($transcribing) { Stop-Transcript | Out-Null }
    }
    if ($log) {
        $report.Add("Transcript=$log")
        try { $report | Set-Content -LiteralPath ($log + '.report.txt') -Encoding utf8 }
        catch { Show-Warn ('Could not write separate report: ' + $_.Exception.Message) }
    }
    if ($success) { Show-Ok 'DONE' }
    try { Show-Copy $report.ToArray() } catch { Show-Warn 'Clipboard unavailable. Copy the following report.'; $report | ForEach-Object { Write-Host $_ -ForegroundColor DarkYellow } }
    Show-Next $steps
    if (-not $success) { exit 1 }
}
