# Forever Route Probe 0.1.0-beta.1 — DRAFT, not cleared

Cleared date: pending independent review.
Compared with: first candidate; no previous cleared release.

Summary: Records a route dry run so its discoveries, XP, quests and profession stops can be reconstructed afterward.

Added: Automatic recording on a fresh level-one character, manual markers, movement points, trainer visits, direct discovery messages and one-block export. Sessions resume after normal reloads and remain separated when the client changes. Classic Era is included as a smoke-test option.

Still limited: No native client or Windows installer test yet. A trainer visit does not prove a purchase. Ambiguous XP snapshots remain unresolved, and crash losses before the game's next save remain possible. This build does not generate or execute an RXP guide.

Owner action: Await Claude Launch Prep review and the resulting controlled test instructions.

Addon ID: ForeverRouteProbe
Wrapper/hash/reviewer: not assigned; author cannot supply independent clearance.
