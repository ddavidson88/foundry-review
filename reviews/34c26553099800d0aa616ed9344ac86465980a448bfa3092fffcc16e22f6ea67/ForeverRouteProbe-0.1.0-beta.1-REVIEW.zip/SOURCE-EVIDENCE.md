# Source evidence — checked 2026-10-23

Existing-addons comparison was performed before the custom implementation decision and completed with current counts in this recovery turn. This private recorder follows useful API/event patterns; no third-party source or RestedXP guide content is bundled.

| Candidate | Displayed downloads, Oct 23 | Fit and remaining gap |
|---|---:|---|
| [RXP Live Recorder](https://www.curseforge.com/wow/addons/rxp-live-recorder) | 28 | Author describes quest, trainer, flight and manual waypoint recording into RXP. Automatic discovery-XP capture is not documented. |
| [RXP Studio](https://www.curseforge.com/wow/addons/rxp-studio) | 7 | Broader guide-authoring workflow. Inspected recorder handles quest and interaction events; discovery awards are not its capture focus. |
| [DystinctLocations](https://github.com/jordanella/DystinctLocations) | No matching CurseForge count confirmed | Retail exploration logger; inspected version logs generic XP/subzone changes, lacks source attribution, and subtracts XP across level boundaries. Do not confuse it with Dystinct Earthen Skyriding. |

Counts are source observations, not compatibility/quality proof. Searches: exact project names plus exploration/route recorder terms. Live Recorder's own page was opened by the author; Studio was opened by the parallel source researcher and its 7 count also appears on the Live Recorder author's project list. Original inspection pins are in UPSTREAM-PINS.json.

RXP Studio pin dcb2630ba7767ac697fa248836fd0b2d4945af43, `Recorder/EventCapture.lua`, illustrates coordinates and multiple QUEST_ACCEPTED signatures. DystinctLocations pin 5adf29afeb86c8d50da262a9d9602012b7b0c907 illustrates location snapshots. Native Forever event timing is still unknown; this candidate keeps raw observations.

## A1 interface evidence

- [RXPGuides TOC, pinned Oct 22 commit](https://github.com/RestedXP/RXPGuides/blob/9536b5a9ee7e55745618a57dad43df2c4312ea16/RXPGuides.toc): general interface includes 16001 and 11509; Interface-Classic is 11509. Fetched directly with GitHub connector on Oct 23.
- [Same commit, RXPGuides.lua](https://github.com/RestedXP/RXPGuides/blob/9536b5a9ee7e55745618a57dad43df2c4312ea16/RXPGuides.lua), lines 202–205, maps the 16000–19999 interface range to FOREVER. This is addon-author mapping, not Blizzard confirmation of every API.
- [Pinned RXP Studio TOC](https://github.com/cgdops/RXP_Studio/blob/dcb2630ba7767ac697fa248836fd0b2d4945af43/RXP_Studio.toc): also contains 16001 and Classic 11509 (parallel researcher source read).
- [Client UI source mirror](https://github.com/Gethe/wow-ui-source/commit/8165d4cd6e48d606369336cc3a7977902310e81e): classic_era HEAD observed as 1.15.9 (70003), Sept 29. Community mirror corroboration only.

TOC `16001, 11509` is therefore source-supported. The probe stores the actual GetBuildInfo and WOW_PROJECT_ID at run time; no owner PC result is asserted. Test fixtures' build numbers are synthetic and are never release evidence. Era event results must be labeled native Classic Era; they do not establish Forever exploration rewards, boats, quest requirements or trainer availability.

## Route facts explicitly outside this candidate

No change to exploration XP estimates, boat destinations, trainer prices, or eligibility is implemented. The provisional direct Auberdine–Stormwind route and estimated XP remain research items. This recorder is the means to collect actual event/coordinate evidence. A discovery coordinate is where the event arrived, not a mathematical boundary.
