# First implementation review — ForeverRouteProbe 0.1.0-beta.1

TO: cLaunchPrep (Claude Launch Prep; provisional registration pending)
FROM: gLaunchPrep (GPT Launch Prep)
Date: 2026-10-23, America/Chicago
Verdict requested: independent implementation findings, then exact-byte clearance only when applicable native/install gates are met. This package is **NOT CLEARED**.

## Scope and authority

Dustin authorized the probe build after the design handoff, retaining GPT as author and Claude as reviewer. Design r1: https://drive.google.com/file/d/1gc_YxRTqyJPKb68Ga0z70O1k_X4ci0Q9/view . A1: https://drive.google.com/file/d/14a4WDOo_W4dosYKVHaDdy6SFAe55VyWs/view . A1 is included in this first candidate; source was not frozen when received. It resolves the earlier beta-only test scheduling concern by authorizing official Classic Era smoke tests.

Original context handoff: https://drive.google.com/file/d/1SaqDfsbSZM873AXk577BfLISgO6FeKZh/view . Receipt/start and addendum Status files are preserved verbatim under records/. No latest matching GPT checkpoint existed in the recovered search set; local unfinished source and its start note were resumed, not silently recreated. The first review archive is now the reproducible recovery base.

## Implemented

- B1: localized discovery reward/no-reward patterns, both UI_INFO_MESSAGE and CHAT_MSG_SYSTEM, channel/area/raw text, duplicate links. No inference of exploration from generic XP changes.
- B2: fresh level-one autoarm, event recording while armed, reload/relog markers, explicit XP gaps, preserved raw history, no automatic clearing. `/probe save` is an optional explicit reload and crash exposure is documented.
- B3: `/probe export` plus status button, one copyable JSONL block, minimal start/stop chat, packaged RUN-ME and fresh-install script. Real independent clearance and exact reviewed ZIP are required for installation; absent clearance defaults to read-only preflight. No fake stamp supplied.
- A1: TOC 16001 + 11509, optional API guards/capability diagnostics, actual client identifiers, separate sessions on client/recorder change, bounded beta/Era/Forever target discovery. Era is a test platform, not proof of Forever mechanics.
- Additional internal author checks found and fixed stale-XP rollover handling, one-argument quest accepts, unconfirmed selected-target identity and malformed nested saved data. These checks are not the owner's independent Claude review.

## Review focus and residual risks

1. Discovery parsing and duplicate semantics; no broad player-chat capture. If native format/channel is absent, capability evidence must make the problem diagnosable before a long run.
2. XP rollover values are provisional cross-checks; mixed state is held and contradicted values link via supersedes_seq. Offline analysis must honor these labels and must not blindly sum xp_update deltas.
3. SavedVariables persistence and client separation; preserve invalid/unknown schemas without rewriting them. No migrations or file cleanup are included.
4. Installer must pass Windows 5.1 checks and preflight before actual install clearance. Do not apply Foundry-app R1/R2/R3 tests as if this were a Foundry build; the delivery-path native requirement and exact-byte review still apply.
5. UI copy length, native performance and game events are untested. Actual skill purchase evidence is distinct from opening a trainer. An unconfirmed target is not a quest-giver claim.

## Reproduction and budgets

Run `python3 tests/test_probe.py`; 39 mocked Lua 5.1 tests passed. `tests/sample-lean.jsonl` and `sample-full.jsonl` are synthetic analyzer fixtures. SCHEMA.md is the candidate contract for your proposed offline analyzer; consumers must preserve client identity, raw messages, duplicates and provisional/unknown XP. No Foundry integration or shared contract adoption is asserted.

BUILD.py deterministically packages frozen source/logs with a SHA-256 manifest. Reviewer gets full ZIP and mandatory one raw part; both are exact same bytes because this candidate is below 3.6 MB. Direct Drive IDs/full hashes live in completion Status outside the ZIP. Do not review an unverified reconstructed copy.

Budget targets: whole compressed review package <50,000 B; code archive <9 MB (project rule); one `/probe` command family; one small status button plus export window; breadcrumb sample interval 2 s. Max 20,000 records/session, approximately 2.5 MB JSON event bytes/session, 10 retained sessions. These are logical caps, not a proven 3 MB SV or memory cap. Native idle memory target <1 MB and CPU cost are **unmeasured**. Actual payload/archive bytes are in completion Status. Growth risk: all 10 sessions and Lua table overhead; stop-with-warning rather than deletion.

## Remaining steps and handoff

Claude: verify exact ZIP hash, inspect code/installer/schema, rerun mocked tests, return blocking findings or source-review result; coordinate read-only Windows W0 and native S1–S6 with GPT after script review. No long launch run before discovery evidence works. If all required release conditions later pass, publish truthful clearance and unchanged wrapper under normal 02B; draft changelog included.

GPT keeps author responsibility. Awaiting Claude review is the only next code step; owner can advance it now by pinging Claude Launch Prep. Native tests are not yet runnable owner instructions.

Deferred: actual launch itinerary, verified XP totals/boat route, tiny dummy RXP import test, offline analyzer implementation, and change-source tracking referenced in A1. No additional vidIQ credits spent; no background monitoring is claimed. These remain in launch planning, not silently completed by this recorder.

Rules used: 01 r1.46; 02 r1.56; 02A r1.5; 02B r1.10; 02C r1.8; 02E r1.9; applicable 02F/03/04; Bulletin 0046. Review recommendation FULL, advanced reasoning for event persistence and delivery; actual independent implementation review pending.
