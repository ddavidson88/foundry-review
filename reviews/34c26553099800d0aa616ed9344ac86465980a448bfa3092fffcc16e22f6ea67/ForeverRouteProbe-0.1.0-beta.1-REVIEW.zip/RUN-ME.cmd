@echo off
setlocal
where pwsh >nul 2>nul
if errorlevel 1 (
  echo PowerShell 7 was not found. No files were changed. Report this to GPT Launch Prep.
  pause >nul
  exit /b 1
)
rem Normal launcher is pwsh; delivery stays inside Windows PowerShell 5.1.
rem Exact reviewer clearance plus ZIP enables install; otherwise read-only preflight.
rem No execution-policy change or elevation.
set "PROBE_INSTALLER_FILE=%~dp0Installer.ps1"
pwsh -NoLogo -NoProfile -Command "& (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe') -NoLogo -NoProfile -File $env:PROBE_INSTALLER_FILE -Auto; exit $LASTEXITCODE"
set "probe_result=%errorlevel%"
rem Keep completed NEXT STEPS visible without output after it.
pause >nul
exit /b %probe_result%
