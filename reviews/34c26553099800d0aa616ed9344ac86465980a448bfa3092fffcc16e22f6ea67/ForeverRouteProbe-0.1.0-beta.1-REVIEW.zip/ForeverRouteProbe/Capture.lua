local name,P=...
local F=CreateFrame("Frame")
P.frame=F
local formats={{"ERR_ZONE_EXPLORED_XP","discovery_xp"},{"ERR_ZONE_EXPLORED","discovery"},{"ERR_SKILL_GAINED_S","skill_learned"},{"ERR_LEARN_SPELL_S","spell_learned"}}
P.matchers={}
-- Supports localized positional substitutions (%2$d) and literal pattern punctuation.
function P.compile(fmt)
    if type(fmt)~="string" or fmt=="" then return nil end
    local out,order={},{}; local i,n=1,0
    while i<=#fmt do
        local tail=fmt:sub(i)
        local token,index,kind=tail:match("^(%%(%d+)%$([sd]))")
        if not token then token,kind=tail:match("^(%%([sd]))") end
        if token then n=n+1; order[n]=tonumber(index) or n; out[#out+1]=kind=="d" and "(%d+)" or "(.-)"; i=i+#token
        elseif tail:sub(1,2)=="%%" then out[#out+1]="%%"; i=i+2
        else local c=fmt:sub(i,i); out[#out+1]=c:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])","%%%1"); i=i+1 end
    end
    return "^"..table.concat(out).."$",order
end
function P.setupFormats()
    for _,format in ipairs(formats) do
        local key,kind=format[1],format[2]
        local pat,order=P.compile(_G[key]); P.capabilities.formats[key]=pat and "available" or "missing"
        if pat then P.matchers[#P.matchers+1]={key=key,kind=kind,pattern=pat,order=order} end
    end
end
function P.message(channel,msg)
    if type(msg)~="string" then return end
    for _,m in ipairs(P.matchers) do
        local a,b=msg:match(m.pattern)
        if a then
            local args={}; args[m.order[1] or 1]=a; if b then args[m.order[2] or 2]=b end
            local data={channel=channel,message=msg,format=m.key,area=(m.kind=="discovery" or m.kind=="discovery_xp") and args[1] or nil,
                learned=(m.kind=="skill_learned" or m.kind=="spell_learned") and args[1] or nil,amount=m.kind=="discovery_xp" and tonumber(args[2]) or nil}
            -- Preserve duplicates as evidence, but link a second delivery to its first record.
            local last=P.lastMessage
            if last and last.message==msg and P.now()-last.t<0.5 and last.segment==(P.session and P.session.segment) then data.duplicate_of=last.seq end
            local r=P.append(m.kind,data)
            if r and not data.duplicate_of then P.lastMessage={message=msg,t=P.now(),seq=r.seq,segment=r.segment} end
            return
        end
    end
    -- UI_INFO_MESSAGE is game feedback, not player chat. Keep unknown messages to diagnose formats.
    if channel=="UI_INFO_MESSAGE" then P.append("ui_info",{message=msg,channel=channel}) end
end
function P.observeXP(event,announced)
    local s=P.session; if not s or not s.active then return end
    local cur=P.xp()
    if event=="PLAYER_LEVEL_UP" then P.append("level_up",{announced=announced}); P.pendingLevel=tonumber(announced); return end
    local previous=s.baseline; local previousValid=previous and P.validXP(previous)
    local delta,reason=P.delta(previous,cur)
    -- A level announcement can precede updated UnitLevel/UnitXP. Never advance an incoherent baseline.
    local pending=P.pendingLevel and cur.level and P.pendingLevel>cur.level
    local mixedMax=previousValid and cur.level==previous.level and cur.max~=previous.max
    -- Identical XP with a new level can be the old XP awaiting rollover. Wait for a
    -- different observation; raw events remain available if the values truly coincide.
    local mixedRollover=previousValid and cur.level==previous.level+1 and cur.xp==previous.xp
    if pending or not P.validXP(cur) or mixedMax or mixedRollover then
        if event~="deferred" then P.append("xp_update",{previous=previous,current=cur,status="pending_level_state"}) end
        P.pendingXP=true; return
    end
    local decrease=previousValid and cur.level==previous.level and cur.xp<previous.xp
    local prior=P.lastRollover
    if prior and (prior.level~=cur.level or P.now()-prior.t>1) then prior=nil end
    if decrease and not prior and (not P.pendingDecrease or P.now()-P.pendingDecrease<1) then
        -- XP may reset before the level notification arrives. Give that state a brief
        -- reconciliation window, then preserve an explicit unknown gap if it persists.
        if not P.pendingDecrease then P.pendingDecrease=P.now() end
        if event~="deferred" then P.append("xp_update",{previous=previous,current=cur,status="pending_level_state"}) end
        P.pendingXP=true; return
    end
    if decrease then
        -- A later sample disproves a prior coherent-looking sample. Preserve it and
        -- explicitly invalidate the earlier derived delta instead of stalling forever.
        P.append("xp_update",{previous=previous,current=cur,status="inconsistent_xp_reset",supersedes_seq=prior and prior.seq,
            rollover_previous=prior and prior.previous})
        P.lastRollover=nil
    else
        local r=P.append("xp_update",{previous=previous,current=cur,delta=delta,status=reason,provisional=reason=="one_level" and true or nil})
        if reason=="one_level" and r and r.kind=="xp_update" then P.lastRollover={seq=r.seq,previous=previous,t=P.now(),level=cur.level} end
    end
    s.baseline=cur; P.pendingXP=nil; P.pendingDecrease=nil
    if P.pendingLevel and cur.level>=P.pendingLevel then P.pendingLevel=nil end
end
function P.npc()
    for _,unit in ipairs({"npc","questnpc","target"}) do
        if P.call(UnitExists,unit) and not P.call(UnitIsUnit,unit,"player") and not P.call(UnitCanAttack,"player",unit) and not P.call(UnitIsDeadOrGhost,unit) then
            local guid=P.call(UnitGUID,unit); local id=guid and guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
            -- A selected friendly target need not be the unit being interacted with.
            return {name=P.call(UnitName,unit),guid=guid,id=tonumber(id),unit=unit,
                confidence=unit=="target" and "unconfirmed_target" or "interaction_token"}
        end
    end
    return {reason="interaction_unit_unavailable"}
end
function P.skills()
    local out={}
    local n=P.call(GetNumSkillLines)
    if n then
        for i=1,n do
            local title,header,_,rank,_,_,max=P.call(GetSkillLineInfo,i)
            if title and not header then out[title]={rank=rank,max=max} end
        end
        return out,"skill_lines"
    end
    if type(GetProfessions)=="function" and type(GetProfessionInfo)=="function" then
        local ids={P.call(GetProfessions)}
        for _,id in pairs(ids) do local title,_,rank,max,_,_,skillID=P.call(GetProfessionInfo,id); if title then out[title]={rank=rank,max=max,id=skillID} end end
        return out,"professions"
    end
    return out,"unavailable"
end
local direct={ZONE_CHANGED="zone_change",ZONE_CHANGED_INDOORS="zone_change",ZONE_CHANGED_NEW_AREA="zone_change",TAXIMAP_OPENED="taxi_opened",PLAYER_DEAD="death",PLAYER_ALIVE="alive",PLAYER_UNGHOST="unghost",PLAYER_LOGOUT="logout",PLAYER_CONTROL_LOST="control_lost",PLAYER_CONTROL_GAINED="control_gained"}
function P.onEvent(_,event,...)
    if event=="ADDON_LOADED" then if (...)==name then P.load(); P.setupFormats() end; return end
    if event=="PLAYER_ENTERING_WORLD" then
        P.enter(...); P.skillBase=select(1,P.skills()); return
    end
    if not P.session or not P.session.active then return end
    if event=="UI_INFO_MESSAGE" then local _,msg=...; P.message(event,msg)
    elseif event=="CHAT_MSG_SYSTEM" then P.message(event,(...))
    elseif event=="CHAT_MSG_COMBAT_XP_GAIN" then P.append("kill_xp_message",{message=(...)})
    elseif event=="PLAYER_XP_UPDATE" then if (...)=="player" then P.observeXP(event) end
    elseif event=="PLAYER_LEVEL_UP" then P.observeXP(event,(...))
    elseif event=="QUEST_ACCEPTED" then
        local a,b=...; local index,id
        if b~=nil then index,id=a,b else id=a end
        P.append("quest_accepted",{id=id,index=index,argument_count=select("#",...),arg1=a,arg2=b,npc=P.npc(),
            title=id and C_QuestLog and P.call(C_QuestLog.GetTitleForQuestID,id)})
    elseif event=="QUEST_TURNED_IN" then local id,xp,money=...; P.append("quest_turned_in",{id=id,xp=xp,money=money,npc=P.npc(),title=C_QuestLog and P.call(C_QuestLog.GetTitleForQuestID,id)})
    elseif event=="TRAINER_SHOW" then P.append("trainer_opened",{npc=P.npc()})
    elseif event=="SKILL_LINES_CHANGED" then
        local cur,method=P.skills(); local changed={}
        for title,v in pairs(cur) do local old=P.skillBase and P.skillBase[title]; if not old or old.rank~=v.rank then changed[title]={previous=old,current=v} end end
        P.append("skills_changed",{method=method,changes=changed,baseline_known=P.skillBase~=nil}); P.skillBase=cur
    elseif direct[event] then P.append(direct[event],{event=event}) end
end
F:SetScript("OnEvent",P.onEvent)
for _,event in ipairs({"ADDON_LOADED","PLAYER_ENTERING_WORLD","UI_INFO_MESSAGE","CHAT_MSG_SYSTEM","CHAT_MSG_COMBAT_XP_GAIN","PLAYER_XP_UPDATE","PLAYER_LEVEL_UP","QUEST_ACCEPTED","QUEST_TURNED_IN","TRAINER_SHOW","SKILL_LINES_CHANGED","ZONE_CHANGED","ZONE_CHANGED_INDOORS","ZONE_CHANGED_NEW_AREA","TAXIMAP_OPENED","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_LOGOUT","PLAYER_CONTROL_LOST","PLAYER_CONTROL_GAINED"}) do
    local ok=pcall(F.RegisterEvent,F,event); P.capabilities.events[event]=ok and "registered" or "unsupported"
end
local elapsed=0
local xpElapsed=0
F:SetScript("OnUpdate",function(_,dt)
    xpElapsed=xpElapsed+dt
    if xpElapsed>=0.1 then
        xpElapsed=0
        if P.pendingXP then P.observeXP("deferred") end
    end
    elapsed=elapsed+dt; if elapsed<2 then return end; elapsed=0
    if not P.session or not P.session.active then return end
    local q=P.position(); local b=P.lastPos
    local moved=not b or q.map~=b.map or q.valid~=b.valid or q.taxi~=b.taxi or
        (q.valid and b.valid and (math.abs(q.x-b.x)>0.00001 or math.abs(q.y-b.y)>0.00001)) or
        (q.wx and b.wx and (math.abs(q.wx-b.wx)>0.5 or math.abs(q.wy-b.wy)>0.5))
    if moved then P.append("breadcrumb"); P.lastPos=q end
end)
