local _,P=...
local status=CreateFrame("Button",nil,UIParent,"UIPanelButtonTemplate")
status:SetSize(180,24); status:SetPoint("TOP",UIParent,"TOP",0,-70)
status:SetMovable(true); status:EnableMouse(true); status:RegisterForDrag("LeftButton")
status:SetScript("OnDragStart",function(self) self:StartMoving() end)
status:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
function P.updateUI()
    status:SetText(P.session and P.session.active and "Probe recording | Export" or "Probe stopped | Export")
end
P.updateUI()
function P.exportText(full)
    local s=P.session; if not s then return nil end
    local meta={format="FOREVER_ROUTE_PROBE_V1",schema=s.schema,id=s.id,character=s.character,guid=s.guid,version=s.version,
        build=s.build,locale=s.locale,class=s.class,race=s.race,started=s.started,capabilities=s.capabilities,addons=s.addons,
        active=s.active,records=#s.events,breadcrumbs_included=full and true or false}
    local lines={P.json({header=meta})}; local count=0
    for _,r in ipairs(s.events) do
        if full or r.kind~="breadcrumb" then lines[#lines+1]=P.json(r); count=count+1 end
    end
    lines[#lines+1]=P.json({footer={id=s.id,exported=count,total=#s.events,complete=true}})
    return table.concat(lines,"\n")
end
function P.showExport(full)
    local text=P.exportText(full)
    if not text then P.say("no session on this character. /probe start to begin."); return end
    if not P.exportFrame then
        local w=CreateFrame("Frame",nil,UIParent,"BasicFrameTemplateWithInset")
        w:SetSize(700,470); w:SetPoint("CENTER"); w:SetFrameStrata("DIALOG")
        w.TitleText:SetText("Route Probe: Ctrl+A, Ctrl+C; paste the whole block")
        local scroll=CreateFrame("ScrollFrame",nil,w,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",16,-35); scroll:SetPoint("BOTTOMRIGHT",-34,16)
        local box=CreateFrame("EditBox",nil,scroll)
        box:SetMultiLine(true); box:SetFontObject(ChatFontNormal); box:SetWidth(635); box:SetAutoFocus(false); box:SetMaxLetters(0)
        box:SetScript("OnEscapePressed",function() w:Hide() end)
        scroll:SetScrollChild(box); w.box=box; P.exportFrame=w
    end
    P.exportFrame:Show(); P.exportFrame.box:SetText(text); P.exportFrame.box:SetFocus(); P.exportFrame.box:HighlightText()
end
status:SetScript("OnClick",function() P.showExport(false) end)
SLASH_FOREVERROUTEPROBE1="/probe"
SlashCmdList.FOREVERROUTEPROBE=function(msg)
    local cmd,rest=msg:match("^%s*(%S*)%s*(.-)%s*$"); cmd=(cmd or ""):lower()
    if cmd=="start" then P.start("manual"); P.skillBase=select(1,P.skills())
    elseif cmd=="stop" then P.stop()
    elseif cmd=="export" then P.showExport(rest:lower()=="full")
    elseif cmd=="mark" then P.append("mark",{note=rest:sub(1,1000)})
    elseif cmd=="save" then
        if P.call(InCombatLockdown) then P.say("wait until out of combat to checkpoint."); return end
        P.append("checkpoint_requested"); if ReloadUI then ReloadUI() end
    elseif cmd=="hide" then status:Hide()
    elseif cmd=="show" then status:Show()
    else P.say((P.session and P.session.active and "Recording" or "Stopped")..". /probe start | stop | export [full] | mark note | save | hide | show") end
end
