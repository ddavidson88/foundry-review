local _, P = ...
P.version, P.schema = "0.1.0-beta.1", 1
P.maxRecords, P.maxSessions, P.maxBytes = 20000, 10, 2500000
P.capabilities = {events = {}, formats = {}}
local function call(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, a,b,c,d,e,f,g = pcall(fn, ...)
    if ok then return a,b,c,d,e,f,g end
end
P.call = call
function P.now() return call(GetTime) or 0 end
function P.wall() return call(GetServerTime) or call(time) or 0 end
function P.say(s) if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("Route Probe: "..s) end end
function P.identity()
    local name = call(UnitName, "player")
    local realm = call(GetRealmName)
    local guid = call(UnitGUID, "player")
    if not name or not realm or not guid then return nil end
    return name.."-"..realm:gsub("%s", ""), guid
end
-- Flavor is a metadata hint derived from exposed identifiers, never a mechanics claim.
function P.client()
    local v,b,d,i=call(GetBuildInfo)
    local project=type(WOW_PROJECT_ID)=="number" and WOW_PROJECT_ID or nil
    local flavor="unknown"
    if i==16001 then flavor="Forever"
    elseif project and WOW_PROJECT_CLASSIC and project==WOW_PROJECT_CLASSIC then flavor="Classic Era"
    elseif project and WOW_PROJECT_MAINLINE and project==WOW_PROJECT_MAINLINE then flavor="Mainline" end
    return {version=v,build=b,date=d,interface=i,projectID=project,flavor=flavor,flavorSource="client_identifiers"}
end
function P.sameClient(a,b)
    return type(a)=="table" and a.version==b.version and a.build==b.build and a.interface==b.interface and a.projectID==b.projectID
end
function P.xp()
    return {level=call(UnitLevel,"player"), xp=call(UnitXP,"player"), max=call(UnitXPMax,"player"), rested=call(GetXPExhaustion)}
end
function P.validXP(x)
    return type(x.level)=="number" and x.level>0 and type(x.xp)=="number" and x.xp>=0 and type(x.max)=="number" and x.max>0 and x.xp<x.max
end
function P.delta(a,b)
    if not a or not P.validXP(a) or not P.validXP(b) then return nil,"unavailable" end
    if b.level==a.level and b.xp>=a.xp then return b.xp-a.xp,"same_level" end
    if b.level==a.level+1 then return a.max-a.xp+b.xp,"one_level" end
    return nil,"unresolved_level_order_or_gap"
end
function P.position()
    local q = {zone=call(GetZoneText), subzone=call(GetSubZoneText), valid=false, reason="map_unavailable"}
    q.map = C_Map and call(C_Map.GetBestMapForUnit,"player")
    local pos = q.map and C_Map and call(C_Map.GetPlayerMapPosition,q.map,"player")
    if pos then
        local x,y=call(pos.GetXY,pos)
        if type(x)=="number" and type(y)=="number" and x>=0 and x<=1 and y>=0 and y<=1 then
            q.x,q.y,q.valid,q.reason=x,y,true,nil
        else q.reason="position_invalid" end
    elseif q.map then q.reason="position_unavailable" end
    local x,y,z,instance = call(UnitPosition,"player")
    if type(x)=="number" and type(y)=="number" then q.wx,q.wy,q.wz,q.instance=x,y,z,instance end
    q.taxi=call(UnitOnTaxi,"player") and true or false
    return q
end
-- Deterministic, non-executable JSON lines for export; SV remains Lua managed by WoW.
local function quote(s)
    return '"'..s:gsub('[%z\1-\31\\"]',function(c)
        if c=='"' then return '\\"' elseif c=='\\' then return '\\\\' end
        return string.format('\\u%04x',string.byte(c))
    end)..'"'
end
function P.json(v)
    local t=type(v)
    if t=="string" then return quote(v) end
    if t=="number" then if v~=v or v==math.huge or v==-math.huge then return "null" end; return string.format("%.17g",v) end
    if t=="boolean" then return tostring(v) end
    if t~="table" then return "null" end
    local keys,out={},{}
    for k in pairs(v) do keys[#keys+1]=tostring(k) end
    table.sort(keys)
    for _,k in ipairs(keys) do local value=v[k]; if value==nil then value=v[tonumber(k)] end; out[#out+1]=quote(k)..":"..P.json(value) end
    return "{"..table.concat(out,",").."}"
end
function P.snapshot(kind,data)
    return {kind=kind,data=data or {},t=P.now(),at=P.wall(),xp=P.xp(),pos=P.position(),segment=P.session and P.session.segment or 0}
end
function P.append(kind,data)
    local s=P.session
    if not s or not s.active then return end
    local r=P.snapshot(kind,data); r.seq=#s.events+1
    local bytes=#P.json(r)+1
    if #s.events>=P.maxRecords-1 or s.bytes+bytes>P.maxBytes-2048 then
        r=P.snapshot("limit_reached",{records=#s.events,bytes=s.bytes}); r.seq=#s.events+1
        s.events[#s.events+1]=r; s.bytes=s.bytes+#P.json(r)+1; s.active=false
        P.say("recording stopped at data limit. Export before starting another session.")
        if P.updateUI then P.updateUI() end
        return r
    end
    s.events[#s.events+1]=r; s.bytes=s.bytes+bytes
    return r
end
function P.start(reason)
    if not P.db then return end
    if P.session and P.session.active then return end
    if #P.db.sessions>=P.maxSessions then P.say("session limit reached; existing data kept. Export and archive the saved-data file."); return end
    local key,guid=P.identity(); if not key then P.say("character identity unavailable; try /probe start after loading."); return end
    local build=P.client()
    local _,class=call(UnitClass,"player"); local _,race=call(UnitRace,"player")
    local s={id=tostring(P.wall())..":"..tostring(#P.db.sessions+1), character=key,guid=guid,version=P.version,schema=P.schema,
        build=build,locale=call(GetLocale),class=class,race=race,started=P.wall(),
        active=true,events={},bytes=0,segment=1,capabilities=P.capabilities,addons=P.addons or {},baseline=P.xp()}
    P.db.sessions[#P.db.sessions+1]=s; P.db.current[key]=#P.db.sessions; P.db.seen[guid]=true; P.session=s
    P.lastMessage,P.lastPos,P.pendingLevel,P.pendingXP,P.lastRollover,P.pendingDecrease=nil,nil,nil,nil,nil,nil
    P.append("session_start",{reason=reason}); P.say("recording started. /probe export to copy; /probe stop to stop.")
    if P.capabilities.formats.ERR_ZONE_EXPLORED_XP~="available" then P.append("capability_warning",{reason="discovery_xp_format_missing"}) end
    if P.updateUI then P.updateUI() end
end
function P.enter(login,reload)
    if not P.db then return end
    local key,guid=P.identity(); if not key then return end
    local index=P.db.current[key]; local s=index and P.db.sessions[index]
    if s and (s.guid~=guid or s.character~=key) then s=nil end -- Same name reused: never merge different characters.
    P.session=s
    if s and s.active and (s.version~=P.version or not P.sameClient(s.build,P.client())) then
        -- Keep prior records tied to their original client. Continue in a separate session.
        local previousID=s.id
        s.active=false; s.closedReason="client_changed"; P.session=nil
        P.start("client_changed")
        if P.session then P.append("client_transition",{previousSession=previousID}) end
        s=P.session
        P.entered=true -- New session is already segment 1; do not treat it as a reload.
    end
    if not s then
        local x=P.xp()
        if not P.db.seen[guid] and x.level==1 and x.xp==0 then P.start("fresh_character")
        elseif not P.offered and x.level and x.level<10 then P.say("use /probe start to record this character."); P.offered=true end
    elseif s.active and not P.entered then
        s.segment=(s.segment or 0)+1
        local cur=P.xp()
        if s.baseline and (cur.level~=s.baseline.level or cur.xp~=s.baseline.xp) then
            P.append("xp_unaccounted",{previous=s.baseline,current=cur,reason="reload_or_relog_gap"})
        end
        if P.validXP(cur) then s.baseline=cur end
        P.say("recording resumed. /probe export to copy.")
    end
    P.entered=true
    P.append("world_entry",{login=login and true or false,reload=reload and true or false,client=P.client()})
    if P.updateUI then P.updateUI() end
end
local function finiteNumber(n)
    return type(n)=="number" and n==n and n~=math.huge and n~=-math.huge
end
local function validSession(s)
    if type(s)~="table" or type(s.id)~="string" or type(s.guid)~="string" or type(s.character)~="string" or
        type(s.events)~="table" or type(s.build)~="table" or type(s.active)~="boolean" or
        not finiteNumber(s.bytes) or s.bytes<0 or not finiteNumber(s.segment) or s.segment<1 or s.segment%1~=0 or
        (s.baseline~=nil and type(s.baseline)~="table") then return false end
    if s.baseline then
        for _,key in ipairs({"level","xp","max","rested"}) do
            if s.baseline[key]~=nil and not finiteNumber(s.baseline[key]) then return false end
        end
    end
    local n,found=#s.events,0
    for k,v in pairs(s.events) do
        found=found+1
        if type(k)~="number" or k%1~=0 or k<1 or k>n or type(v)~="table" or v.seq~=k or type(v.kind)~="string" then return false end
    end
    return found==n
end
function P.load()
    if ForeverRouteProbeDB~=nil and (type(ForeverRouteProbeDB)~="table" or ForeverRouteProbeDB.schema~=P.schema) then
        P.say("unsupported saved-data schema; recording disabled and data preserved."); return
    end
    ForeverRouteProbeDB=ForeverRouteProbeDB or {schema=P.schema,sessions={},current={},seen={}}
    local d=ForeverRouteProbeDB
    if type(d.sessions)~="table" or type(d.current)~="table" or type(d.seen)~="table" then P.say("saved-data structure invalid; recording disabled."); return end
    local count,found=#d.sessions,0
    for k,s in pairs(d.sessions) do
        found=found+1
        if type(k)~="number" or k%1~=0 or k<1 or k>count or not validSession(s) then
            P.say("saved-session structure invalid; recording disabled and data preserved."); return
        end
    end
    if found~=count then P.say("saved-session array invalid; recording disabled and data preserved."); return end
    for key,index in pairs(d.current) do
        if type(key)~="string" or type(index)~="number" or index%1~=0 or not d.sessions[index] then
            P.say("saved-session index invalid; recording disabled and data preserved."); return
        end
    end
    P.db=d
    P.addons={}
    local api=C_AddOns or _G
    local count=call(api.GetNumAddOns) or 0
    for i=1,count do
        local id=call(api.GetAddOnInfo,i)
        if type(id)=="string" then P.addons[id]={version=call(api.GetAddOnMetadata,id,"Version"),loaded=call(api.IsAddOnLoaded,id) and true or false} end
    end
end
function P.stop()
    if P.session and P.session.active then P.append("session_stop"); P.session.active=false; P.say("recording stopped; data kept. /probe export to copy.") end
    if P.updateUI then P.updateUI() end
end
