#!/usr/bin/env python3
"""Deterministic review archive. Rebuilds frozen evidence; does not rerun tests."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = 'ForeverRouteProbe-0.1.0-beta.1-REVIEW.zip'
FIXED = (2026, 10, 23, 0, 0, 0)
FILES = [
    'ForeverRouteProbe/Core.lua', 'ForeverRouteProbe/Capture.lua',
    'ForeverRouteProbe/UI.lua', 'ForeverRouteProbe/ForeverRouteProbe.toc',
    'Installer.ps1', 'RUN-ME.cmd', 'README.md', 'SCHEMA.md',
    'UPSTREAM-PINS.json', 'SOURCE-EVIDENCE.md', 'REVIEW-NOTES.md',
    'CHANGELOG-DRAFT.md', 'BUILD.py', 'tests/test_probe.py',
    'tests/results-mocked.txt', 'tests/sample-lean.jsonl',
    'tests/sample-full.jsonl', 'tests/VALIDATION.md',
    'records/STATUS-RouteProbe-start-20261023.md',
    'records/STATUS-LaunchPrep-20261023T124300Z-GPT-received.md',
    'records/STATUS-LaunchPrep-20261023T125000Z-GPT-addendum.md',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def build(destination):
    entries = {name: (ROOT / name).read_bytes() for name in FILES}
    payload = [{'path': name.split('/', 1)[1], 'sha256': digest(data), 'bytes': len(data)}
               for name, data in sorted(entries.items()) if name.startswith('ForeverRouteProbe/')]
    entries['PAYLOAD-SHA256.json'] = (json.dumps(payload, indent=2) + '\n').encode()
    manifest = [{'path': name, 'sha256': digest(data), 'bytes': len(data)}
                for name, data in sorted(entries.items())]
    entries['MANIFEST-SHA256.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, 'w') as archive:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, FIXED)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compresslevel=9)
    return {'filename': destination.name, 'bytes': destination.stat().st_size,
            'sha256': digest(destination.read_bytes()), 'members': len(entries),
            'runtime_bytes': sum(x['bytes'] for x in payload)}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'delivery' / NAME)
    parser.add_argument('--expected-sha256')
    args = parser.parse_args()
    result = build(args.output)
    print(json.dumps(result, indent=2))
    if args.expected_sha256 and result['sha256'] != args.expected_sha256.lower():
        raise SystemExit('FAIL: rebuilt ZIP SHA-256 differs from expected candidate')
